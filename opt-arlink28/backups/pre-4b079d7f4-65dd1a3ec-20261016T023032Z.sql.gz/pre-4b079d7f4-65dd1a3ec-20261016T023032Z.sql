--
-- PostgreSQL database dump
--

\restrict 14g1aSer1w9DoaPmGgc2ylqhp2hlSOdbSLUl4k7rUOcHruKdoDZ48Gim1UY5CHl

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: DestinationAttractions; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."DestinationAttractions" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "DestinationId" uuid NOT NULL,
    "Name" character varying(120) NOT NULL,
    "Summary" character varying(300),
    "PhotoPath" character varying(255),
    "PhotoAlt" character varying(250),
    "PhotoCredit" character varying(250),
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."DestinationAttractions" OWNER TO arlink28;

--
-- Name: Destinations; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Destinations" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Country" character(2) NOT NULL,
    "Kind" character varying(20) NOT NULL,
    "Status" character varying(20) NOT NULL,
    "ParentId" uuid,
    "Tagline" character varying(160),
    "Summary" character varying(400),
    "Description" text,
    "BestTimeToVisit" character varying(200),
    "HeroPath" character varying(255),
    "HeroAlt" character varying(250),
    "HeroCredit" character varying(250),
    "Latitude" double precision,
    "Longitude" double precision,
    "SortOrder" integer NOT NULL,
    "PublishedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Destinations" OWNER TO arlink28;

--
-- Name: Enquiries; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Enquiries" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Reference" character varying(20) NOT NULL,
    "Type" character varying(20) NOT NULL,
    "Status" character varying(20) NOT NULL,
    "PackageId" uuid,
    "PackageTitle" character varying(200),
    "CheckIn" date,
    "Nights" integer,
    "QuotedTotalMinor" bigint,
    "Currency" character(3),
    "Name" character varying(120) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "Phone" character varying(40),
    "Subject" character varying(200),
    "Message" character varying(4000),
    "ConsentAt" timestamp with time zone NOT NULL,
    "SourceUrl" character varying(500),
    "HandledById" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Enquiries" OWNER TO arlink28;

--
-- Name: Features; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Features" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Label" character varying(200) NOT NULL,
    "Icon" character varying(100),
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Features" OWNER TO arlink28;

--
-- Name: PackageAddOns; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageAddOns" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Name" character varying(200) NOT NULL,
    "Description" character varying(500),
    "Unit" character varying(20) NOT NULL,
    "Currency" character(3) NOT NULL,
    "PriceMinor" bigint NOT NULL,
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageAddOns" OWNER TO arlink28;

--
-- Name: PackageFeatures; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageFeatures" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Section" character varying(30) NOT NULL,
    "FeatureId" uuid,
    "LabelOverride" character varying(200),
    "Footnote" character varying(500),
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageFeatures" OWNER TO arlink28;

--
-- Name: PackageMedia; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageMedia" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Role" character varying(20) NOT NULL,
    "Path" character varying(500) NOT NULL,
    "Alt" character varying(250),
    "Caption" character varying(500),
    "Width" integer,
    "Height" integer,
    "VideoProvider" character varying(20),
    "VideoId" character varying(100),
    "VariantsReady" boolean NOT NULL,
    "SortKey" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PackageMedia" OWNER TO arlink28;

--
-- Name: PackageRates; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageRates" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "SeasonId" uuid NOT NULL,
    "Currency" character(3) NOT NULL,
    "PriceMinor" bigint NOT NULL,
    "ExtraNightPriceMinor" bigint
);


ALTER TABLE public."PackageRates" OWNER TO arlink28;

--
-- Name: PackageStays; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageStays" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "PropertyId" uuid NOT NULL,
    "Nights" integer NOT NULL,
    "RoomType" character varying(100),
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageStays" OWNER TO arlink28;

--
-- Name: Packages; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Packages" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "ProductType" character varying(20) NOT NULL,
    "Details" jsonb,
    "Status" character varying(20) NOT NULL,
    "Title" character varying(200) NOT NULL,
    "Subtitle" character varying(200),
    "Summary" character varying(500),
    "Description" text,
    "Category" character varying(50) NOT NULL,
    "DestinationId" uuid NOT NULL,
    "Nights" integer NOT NULL,
    "MinNights" integer NOT NULL,
    "Adults" integer NOT NULL,
    "Children" integer NOT NULL,
    "PricingBasis" character varying(20) NOT NULL,
    "BaseCurrency" character(3) NOT NULL,
    "FromPriceMinor" bigint,
    "Featured" boolean NOT NULL,
    "SortOrder" integer NOT NULL,
    "SeoTitle" character varying(70),
    "SeoDescription" character varying(160),
    "Version" integer NOT NULL,
    "PublishedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Packages" OWNER TO arlink28;

--
-- Name: Partners; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Partners" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Tagline" character varying(200),
    "LogoPath" character varying(500),
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Partners" OWNER TO arlink28;

--
-- Name: Properties; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Properties" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(200) NOT NULL,
    "PartnerId" uuid,
    "DestinationId" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Properties" OWNER TO arlink28;

--
-- Name: PropertyMedia; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PropertyMedia" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PropertyId" uuid NOT NULL,
    "Path" character varying(500) NOT NULL,
    "Alt" character varying(250),
    "Caption" character varying(500),
    "Width" integer,
    "Height" integer,
    "VideoProvider" character varying(20),
    "VideoId" character varying(100),
    "VariantsReady" boolean NOT NULL,
    "SortKey" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PropertyMedia" OWNER TO arlink28;

--
-- Name: SeasonRanges; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."SeasonRanges" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "SeasonId" uuid NOT NULL,
    "StartDate" date NOT NULL,
    "EndDate" date NOT NULL
);


ALTER TABLE public."SeasonRanges" OWNER TO arlink28;

--
-- Name: Seasons; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Seasons" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "PartnerId" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Seasons" OWNER TO arlink28;

--
-- Name: Staff; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Staff" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Username" character varying(50) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "PasswordHash" text NOT NULL,
    "Role" character varying(20) NOT NULL,
    "IsActive" boolean NOT NULL,
    "FailedLoginAttempts" integer NOT NULL,
    "LockedUntil" timestamp with time zone,
    "LastLoginAt" timestamp with time zone,
    "InvitedById" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Staff" OWNER TO arlink28;

--
-- Name: StaffTokens; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."StaffTokens" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Type" character varying(20) NOT NULL,
    "TokenHash" character varying(64) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "RoleToAssign" character varying(20),
    "StaffId" uuid,
    "ExpiresAt" timestamp with time zone NOT NULL,
    "UsedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."StaffTokens" OWNER TO arlink28;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO arlink28;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public.audit_logs (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "ActorId" character varying(36),
    "Action" character varying(100) NOT NULL,
    "EntityType" character varying(100) NOT NULL,
    "EntityId" character varying(36) NOT NULL,
    "Before" text,
    "After" text,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO arlink28;

--
-- Data for Name: DestinationAttractions; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."DestinationAttractions" ("Id", "DestinationId", "Name", "Summary", "PhotoPath", "PhotoAlt", "PhotoCredit", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Destinations; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Destinations" ("Id", "Slug", "Name", "Country", "Kind", "Status", "ParentId", "Tagline", "Summary", "Description", "BestTimeToVisit", "HeroPath", "HeroAlt", "HeroCredit", "Latitude", "Longitude", "SortOrder", "PublishedAt", "CreatedAt", "UpdatedAt") FROM stdin;
eb2d59e3-ac54-4d93-b88c-3da09d04c9d2	kenya	Kenya	KE	Country	Draft	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
f1da7e79-5a02-49b0-902e-68145c23d5e3	nairobi	Nairobi	KE	Place	Published	eb2d59e3-ac54-4d93-b88c-3da09d04c9d2	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: Enquiries; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Enquiries" ("Id", "Reference", "Type", "Status", "PackageId", "PackageTitle", "CheckIn", "Nights", "QuotedTotalMinor", "Currency", "Name", "Email", "Phone", "Subject", "Message", "ConsentAt", "SourceUrl", "HandledById", "CreatedAt", "UpdatedAt") FROM stdin;
42638c3b-72ce-49d8-934b-b5237a420af4	ENQ-2026-0001	General	New	\N	\N	\N	\N	\N	\N	Playwright test 23:23:46 (ignore)	developers@arlink28.com	+44 7000 000000	Mail test 23:23:46 - contact form	Automated test of the contact form email routing. Please ignore.	2026-10-15 23:23:47.775762+00	/contact	\N	2026-10-15 23:23:47.775762+00	2026-10-15 23:23:47.775762+00
84c66f82-a9de-44b3-b72b-b8a5949891eb	ENQ-2026-0002	Booking	New	\N	\N	\N	\N	\N	\N	Playwright test 23:23:46 (ignore)	developers@arlink28.com	+44 7000 000000	Flight quote: Mail test destination	Service: Flight\nDestination: Mail test destination\nTravellers: 1 person\n\nAutomated test of the quote email routing 23:23:46. Please ignore.	2026-10-15 23:23:57.506447+00	/quote	\N	2026-10-15 23:23:57.506447+00	2026-10-15 23:23:57.506447+00
664f8419-53ce-4f70-8ef4-94b4c00a34b8	ENQ-2026-0003	Booking	New	\N	\N	\N	\N	\N	\N	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	Hotel reservation quote: Cape Town	Service: Hotel reservation\nDestination: Cape Town\nTravellers: 1 person\n\ntesting ignore this	2026-10-15 23:27:48.92886+00	/quote	\N	2026-10-15 23:27:48.92886+00	2026-10-15 23:27:48.92886+00
dfa8b115-ea99-4bfe-b1db-cf397c311a66	ENQ-2026-0004	General	New	\N	\N	\N	\N	\N	\N	Playwright email test	developers@arlink28.com	\N	Email test 2026-10-16T01:04:08.205Z	Automated check that enquiry emails send from production. Safe to delete.	2026-10-16 01:04:13.259535+00	/contact	\N	2026-10-16 01:04:13.259535+00	2026-10-16 01:04:13.259535+00
3965844a-abd7-4635-b4a3-0909e29ff40f	ENQ-2026-0005	Booking	New	\N	\N	\N	\N	\N	\N	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	Flight quote: Cape Town	Service: Flight\nDestination: Cape Town\nTravellers: 1 person\n\ntesting	2026-10-16 01:18:10.009061+00	/quote	\N	2026-10-16 01:18:10.009061+00	2026-10-16 01:18:10.009061+00
098ba038-42e1-4ef6-9a97-3d200c911146	ENQ-2026-0006	Package	New	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Giraffe Manor Family Experience	2026-10-17	5	2657600	USD	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	\N	testing ignore	2026-10-16 02:19:08.923976+00	/contact?package=Giraffe+Manor+Family+Experience&slug=giraffe-manor-family-experience&checkIn=2026-10-17&nights=5	\N	2026-10-16 02:19:08.923976+00	2026-10-16 02:19:08.923976+00
\.


--
-- Data for Name: Features; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Features" ("Id", "Slug", "Label", "Icon", "CreatedAt") FROM stdin;
06d26b77-6072-47c1-a8c9-7f41997e7e83	meet-and-greet	Meet & greet service from the airport to the destination	people-group	2026-10-16 02:13:59.79865+00
29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	vip-airport-to-resort	VIP transfer from airport to resort	plane	2026-10-16 02:13:59.79865+00
2ce2ac79-841c-465b-923f-5dc5106b44e3	tips	Tips	hand-holding-dollar	2026-10-16 02:13:59.79865+00
369530dd-dbcf-4fe7-a4e8-da09eb4206c7	vip-home-to-airport	VIP transfer from home to airport	car	2026-10-16 02:13:59.79865+00
44d688c1-caa2-4f41-87b6-14a95030bca0	vat	VAT	receipt	2026-10-16 02:13:59.79865+00
4578c46a-05f6-4efc-8689-23d57bf4ba05	boules-croquet	Boules & croquet	baseball-bat-ball	2026-10-16 02:13:59.79865+00
55a674d9-c7ff-438e-b14f-81c304b70f52	personal-effects	Personal effects	suitcase	2026-10-16 02:13:59.79865+00
5ed14816-6744-407b-b9c7-3e25dec318af	massage-treatments	Massage treatments	spa	2026-10-16 02:13:59.79865+00
861b903c-b7c1-4cb2-a8e4-b052dc780ec5	afew-giraffe-centre	AFEW Giraffe Centre entry	ticket	2026-10-16 02:13:59.79865+00
a55e53f2-a1e9-479a-a536-6780bf407a41	luxury-spirits	Luxury spirits	wine-bottle	2026-10-16 02:13:59.79865+00
a755ca68-16b1-496a-bcda-8b529a09b921	all-meals	All meals	utensils	2026-10-16 02:13:59.79865+00
ab597b1d-b14b-49e5-b735-42e59c1455bc	retreat-access	Access to The Retreat during check-in & check-out	spa	2026-10-16 02:13:59.79865+00
b17f4b12-ceda-4499-b696-b2a28116674e	orchid-house-dining	Orchid House dining	utensils	2026-10-16 02:13:59.79865+00
c0fc5481-9e17-48d5-8237-fb6a8dc39134	selected-wines	Selected wines	wine-glass-empty	2026-10-16 02:13:59.79865+00
c9d32790-1fd1-469e-8326-6a95ad6ef1cd	house-drinks	House wines, soft drinks, beers & spirits	wine-glass	2026-10-16 02:13:59.79865+00
cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	laundry	Laundry	shirt	2026-10-16 02:13:59.79865+00
dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	wifi	Wi-Fi	wifi	2026-10-16 02:13:59.79865+00
de9ac8e5-85f5-4c7c-8c54-b31d83f94636	champagne	Champagne	champagne-glasses	2026-10-16 02:13:59.79865+00
e6040660-0d06-4f1d-bf65-7d1d5c6db260	karen-langata-transfers	Arrival & departure transfers – Karen & Langata area	van-shuttle	2026-10-16 02:13:59.79865+00
eede9629-2716-46c7-9fcf-406c54cd6b3f	health-insurance	Health insurance	notes-medical	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: PackageAddOns; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageAddOns" ("Id", "PackageId", "Name", "Description", "Unit", "Currency", "PriceMinor", "SortOrder") FROM stdin;
260b795d-707a-42f8-88d7-c453c3569f13	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
2e61a08f-f8bd-459b-8891-0bc2c9d63704	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
3e473e92-0c0b-4e60-bf69-277005ad22dc	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
52af5bb5-a512-4a80-8e53-2673527cd9b2	46a039e6-d50d-4f47-ac0e-30ab22d97535	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
828d1da2-0494-4c8d-9352-211ee5af6509	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
8f21407f-f598-4c2c-80d3-ee6519f05a56	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
\.


--
-- Data for Name: PackageFeatures; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageFeatures" ("Id", "PackageId", "Section", "FeatureId", "LabelOverride", "Footnote", "SortOrder") FROM stdin;
038fb98f-36d8-49f8-a760-7d10da42e7d1	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
06312f38-f3b0-4cb2-8d61-4a3761da8c48	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
06583305-ab55-402c-81eb-c64da909ab00	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
068223b6-90a2-4e07-b26b-c1c20e0cdec5	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
087bc0e2-d591-4a81-97ef-9383a3b01c37	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
090b74e5-2110-46c1-9cef-bcbc61d1043a	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
0a0fd2e2-565c-47e3-9825-393dd6be7eb3	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
0c181280-f6f9-45b6-a1e3-3866499520d1	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
0d6b72ea-819f-41bb-a74b-569bfc89800e	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
0ee4dc84-4bc5-4c69-8550-a03e9560a6bc	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
0fc4cb90-bee4-42a5-b968-9045457178cd	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
0fd2dbac-e63f-4eb2-a759-8009f87c2abc	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
108a5cef-3074-4ca6-aeac-54c01efdcfec	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
1132ae78-f687-45d7-93fb-928c4d0ded36	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
11e619cd-c792-46ab-9e17-1aa2b71e65ee	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
13598801-1663-40dd-950b-47379c4ba1a8	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
16561921-3e3c-4630-985e-2fd320040538	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
17cbcda0-0b8c-4be7-bef9-77f814f65b9a	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
188b1336-726d-40c0-956b-5e968eb0fb94	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
1c7008a3-7a27-4131-b784-93843bceb82c	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
1e6bda17-ffe8-40a1-bc0e-c9b456a1729e	d4d1b4e2-95d8-41fc-88a7-a25103292e81	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
1fcc3e2f-31e0-467e-ac5e-c34e2d561595	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
2047c281-7ef9-416f-ab83-2fdeeb3e57a8	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
227bfbb9-828b-427d-baf5-3a3511304ac5	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
242dc01f-d6ca-4450-a22b-299700cc3e6e	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
2476930b-956e-4bb3-9f2b-3e69d49334c8	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
28a53e67-3359-4432-8248-e9ce52ba543a	46a039e6-d50d-4f47-ac0e-30ab22d97535	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
29744d7c-3fbd-4f91-af1a-d227803026fe	d4d1b4e2-95d8-41fc-88a7-a25103292e81	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
2bc19d77-25aa-4f9a-8466-e148841ffb28	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
2d20db67-94cb-44c9-9d1b-b2ab3f2ad056	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
2e691930-f6a3-430f-b148-ddc24db3bcd3	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
30efa978-29bb-4765-b15d-625e5f61af17	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	A third child is charged in addition to the suite minimum.	\N	5
362967a7-2c0b-4305-bfa1-66ea63e2c66e	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
36db4f2b-5f6f-4b5e-8bcf-038cacd4cf2f	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
3808e902-81d9-4376-a874-868a3bfc02e5	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
38f935bb-1f0b-490b-ab41-1ba5897f2b76	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
395243f9-8c5c-4d16-a813-998a8804cf53	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
3de48299-338c-4ae0-8e13-11b61b064365	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
3ee66a36-e78d-4bca-8752-96999a4b701b	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
3f508b33-6833-4ed2-a370-192a102ce249	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
402c860f-2d5e-4885-9bd3-07e426107339	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
40375be7-abee-4b45-9005-b56566ea855d	5daabefd-e115-48ab-a84e-33e6eb68f7f9	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
40f796a1-0041-4b95-9eeb-69c17bc08976	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
4161ab0b-e92c-4e5f-a0a0-4898a003db42	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
473bb26b-a3a4-496f-95e6-b92a6237d7ae	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
50105c0e-2f41-450a-9c51-759ef7d14f2d	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
50136fc0-8f79-4476-ad1a-fef65926f486	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
50605317-3af7-4495-a43b-e840f144a45c	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
51d43923-5587-47b7-990c-3f2a751cbaf7	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
554ce5e5-8ef1-4be4-be97-a7dd03505343	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
55af0d60-441e-4f37-b34b-2dbfa2b82dab	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
55b4f869-5fcb-4ee4-bcb6-20ca96cee998	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
5967364a-1dec-4c1c-b4dd-8c0ec2976cce	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
5b4dc9bf-75dd-4758-a2d9-66a4ca0ec921	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
5c12f2f4-23da-4bab-b3d1-aa2143664644	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
5ca59984-2a74-411f-bcbb-c2057500845c	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
5e2c7f8d-dfdb-40fe-96d6-7eba1e3502e8	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
5e61f934-caf0-4517-8492-e29777ef989c	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
5ee22d7b-2c80-4efb-91d9-7c2a026c72c3	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
5fd82c12-ff70-4a64-ae93-5cd79ced2ce3	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
604483f5-9006-4263-b752-70efc592f34e	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
60bf6458-ff61-4e01-82ee-b6935b500c5a	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
61dba82e-6c96-46a9-b587-7581a23d32d4	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
63f4692e-9488-4324-b681-d712940a88d4	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
63f71c98-a25f-4faa-9d6b-128347108570	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
692883d8-9af4-4ff3-ac48-2491844d653e	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
6bab6c28-61bf-4d0d-89a8-bff9b0e9584d	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
6fe5f384-e2f5-4d77-afc9-712f1d86b775	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
71c2a1e0-c4e3-42ad-84a2-ace44e754a38	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
720d9e57-793e-498c-bcdd-61e5e333d979	d4d1b4e2-95d8-41fc-88a7-a25103292e81	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
722aa6e5-e1f6-4088-a5eb-fe7517224cf5	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
72b92974-95e1-4d34-987e-3efdbfc12d71	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
735e8d15-4060-4b04-b30d-c3d881cb5836	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
74b59678-854d-4385-aa87-ba711aa620c4	46a039e6-d50d-4f47-ac0e-30ab22d97535	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
76d7f901-c040-4fc9-a196-9f3b14accdf7	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
786d3476-ebfd-4eec-8520-62d61e07fed5	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
79bbabe4-0eaa-4295-9c57-eb121d344b8a	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
7b80b03c-3a39-4e03-be15-d30f4febf228	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
7eaaf0d0-6cba-4c80-8d64-84b21c2b0125	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
81d79c2e-a13b-4a28-9c1e-01ccd2b3b878	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
82e55a20-c462-449b-b854-424a794d5bb0	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
83226d94-eb67-4427-aef5-6b4e2a02cd46	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
8b2cc85e-9912-413c-81eb-5365983c77db	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
8cf769ea-8945-4305-a997-cfc3fbe70c23	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
8d261e6e-3709-4808-a72e-90a1dbd81f14	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
8d6da584-1f9d-40bb-ba6f-1abb13719485	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
90fade15-d6db-4881-bb82-b72a4166f9c1	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
916b2989-b323-4a03-a94f-15365fc98488	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
922bd115-177b-48d7-8228-867bfb28e2b6	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
9327fa1e-1d84-468f-afaf-bbc9d62f2909	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
9383cd36-d5dc-45ca-b909-8deb0ae161c6	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
94c5fdf2-b48e-42ce-a071-a0748ff2d040	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
98092838-3b37-49ff-9c81-9798bd5c14a7	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
98a16d3e-f08a-418e-b39d-ff6fd43e3095	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
98cb7b80-8dc0-4709-b42f-3510d1834e80	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
98f7fa3c-913c-4510-8883-b1ef53b841d1	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
99c4cc6c-c31f-4812-bf18-fc8aba64b7f7	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
9a72a363-0223-486a-984c-120f934bc946	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
9b4f95a1-0b7a-4eff-bf5e-8fda377f7197	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
9c9cde62-7350-4774-8f88-0b47a8b1d622	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
a15a19c8-2eec-4cb2-af1e-5db9f07861b2	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
ac147faa-ee74-4591-ae7a-8adaa44ef3b2	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
ae61edd3-5da8-4ee2-98df-c183685e3f5b	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
b059b941-bf5e-4c17-948e-afb36e5373bb	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
b58a398f-1f1b-4795-a272-97b3bbe4b5be	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
b59248ba-4dd2-42ad-be3d-b92fe226ca67	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
b617f82b-5f2b-4397-a449-2c917696b530	5daabefd-e115-48ab-a84e-33e6eb68f7f9	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
b6463b98-4405-4e0e-8c74-b91ba96da0b0	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
b8fd1394-c23b-4498-bbe8-953a16ec8319	46a039e6-d50d-4f47-ac0e-30ab22d97535	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
b9f906d0-ba10-4e9d-ad62-9972f858d1cc	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
bb8db7ef-43c7-4a97-8f62-6f81b3d4b915	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
bc8f8d7c-d196-44a7-bf79-040409242cdb	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
bf7718af-8a7b-4253-9abe-2b311f6eab6d	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
c0fb4007-82cf-4535-b920-f3aa82e5f4dc	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
c1e3e74b-fafa-4103-9b96-99d4b031709a	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
c28d6889-7509-4949-84b9-0ece7cab46e2	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
c4666a28-20c8-42f1-b496-3f287295e7d6	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
c4f93e28-5576-41c8-b92e-71bdfe631b0e	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
c5f2cc9a-802b-4af3-b9b3-86105593ce61	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
cea7f625-094c-4cb6-8921-eb79afb30bd7	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
d1674775-c053-4cbf-9148-62d474994183	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
d2f079e0-6ef7-4890-898e-59a7e0ab04e3	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
d5862fdb-68ad-4a10-bcae-618dcf57ed5b	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
d59d0032-2a7b-481f-910d-7d00b4af1c95	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
d699982d-2ce8-4bea-8020-d933cc921045	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
d81eeff2-927f-44dd-b1cd-c1e314401102	5daabefd-e115-48ab-a84e-33e6eb68f7f9	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
dbd2858b-8090-4795-b21b-4c36c70ab1fe	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
dc5282e9-2670-4250-8515-6a13edcc2fa9	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
dda8d8e0-c93f-42f2-b347-fa636147862f	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
df163638-0f7c-4e74-8831-2519b89552c8	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
e082cdc5-aad9-4696-a79c-a4cbdba20400	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
e2e23a4d-5efc-4b3d-8b81-5c9718d89b1a	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
e51ba17d-5e5a-4279-8494-39ac37e18dc9	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
e52d1967-623b-4ccb-a521-3868c5b49781	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
e5c66446-59f1-407c-a1c1-3435b77dcf5f	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
e6877b35-f0ff-4a01-8466-e76d70013309	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
e7643f27-00d0-4690-bd56-00ebe0071b54	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
e99cac87-53b5-44a3-8630-f3b3646920eb	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
eacae446-7ae8-4c07-95a2-a87e3e246c08	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
f238f306-d530-4c19-bedc-fe70718edc73	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
f632a3ba-55e0-4a48-9a9b-598eb1048d3b	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
f6b392ea-6cba-4706-823a-67ec1dba2089	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
f6e7e78d-d057-4f1f-abea-e99dfe0babbe	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
f7cae648-422e-49d9-aefa-8fba18634991	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
f84bdc9f-c180-473a-8cb2-2947f252a118	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
f9a78939-74ca-4590-b0c9-b21f21e0d49c	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
f9f84cbe-8cf4-436c-b060-cdb965738ff7	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
fe2d0fb1-9ac3-4cb5-8b55-75b5b4c343ce	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
ffaaa005-b634-4460-869e-51e2f538c471	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
ffd6a489-a051-43c2-a35d-0284ee631102	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
fff75825-58bb-4501-9831-2093d01bd548	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
\.


--
-- Data for Name: PackageMedia; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageMedia" ("Id", "PackageId", "Role", "Path", "Alt", "Caption", "Width", "Height", "VideoProvider", "VideoId", "VariantsReady", "SortKey", "CreatedAt") FROM stdin;
1709de55-f95d-41b7-9393-2426939ebf60	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Hero	/images/packages/gm-signature-escape.jpg	Giraffe Manor Signature Escape	\N	\N	\N	\N	\N	t	0	2026-10-16 02:13:59.79865+00
1883b9a3-29eb-4558-bb17-ad5c87b61531	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Hero	/images/packages/gm-family-friends-3.jpg	Giraffe Manor Family and Friends Retreat (3 Adults)	\N	\N	\N	\N	\N	t	0	2026-10-16 02:13:59.79865+00
890bfea3-3962-4a14-be95-7e8806bbe983	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Hero	/images/packages/gm-family-experience.jpg	Giraffe Manor Family Experience	\N	\N	\N	\N	\N	t	0	2026-10-16 02:13:59.79865+00
8fdf3400-ed4b-4ce4-81c8-11135ffe7ef2	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Hero	/images/packages/gm-extended-family.jpg	Giraffe Manor Extended Family Package	\N	\N	\N	\N	\N	t	0	2026-10-16 02:13:59.79865+00
b4b77a39-317c-4110-9267-bc59b41f82be	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Hero	/images/packages/gm-family-friends-4.jpg	Giraffe Manor Family and Friends Retreat (4 Adults)	\N	\N	\N	\N	\N	t	0	2026-10-16 02:13:59.79865+00
ea8b8053-e775-4758-b7ea-0fb565646842	46a039e6-d50d-4f47-ac0e-30ab22d97535	Hero	/images/packages/gm-solo-escape.jpg	Giraffe Manor Solo Escape	\N	\N	\N	\N	\N	t	0	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: PackageRates; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageRates" ("Id", "PackageId", "SeasonId", "Currency", "PriceMinor", "ExtraNightPriceMinor") FROM stdin;
0bd4d532-0461-4ed4-ad9c-e4277bfb4e66	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	1413000	\N
428f6551-aef9-40cb-a67a-ddd8642b0afa	d4d1b4e2-95d8-41fc-88a7-a25103292e81	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	3720640	\N
54b33ea6-b954-46de-ac61-94a18a8066a4	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	4154220	\N
b752d7b7-678a-4966-a343-0cf6a062f44e	5daabefd-e115-48ab-a84e-33e6eb68f7f9	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	2657600	\N
dde44d13-85c6-4be5-bd2a-ba6eda57a627	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	2863350	\N
ff6d9bb2-8618-4c17-9288-478d89e95bd4	46a039e6-d50d-4f47-ac0e-30ab22d97535	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	698670	\N
\.


--
-- Data for Name: PackageStays; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageStays" ("Id", "PackageId", "PropertyId", "Nights", "RoomType", "SortOrder") FROM stdin;
02b8a807-54b9-4699-ab45-19f148a2da4a	46a039e6-d50d-4f47-ac0e-30ab22d97535	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	3	Superior Single Room	0
24feb341-f6ef-43f9-a144-7f86484cb53b	5daabefd-e115-48ab-a84e-33e6eb68f7f9	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	5	Karen Blixen / Finch Hatton Suite	0
48a08d99-b308-432b-a46b-03af3b26e1d4	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	5	Karen Blixen / Finch Hatton Suites	0
53be891c-6776-46a3-9e9a-856f8f06f6d9	d4d1b4e2-95d8-41fc-88a7-a25103292e81	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	7	Karen Blixen / Finch Hatton Suites	0
f0e1a993-d52b-4d87-b984-4ebc15ee358a	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	5	Superior Room	0
fba07220-0aee-4617-bf05-e5f6ce946776	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	7	Karen Blixen / Finch Hatton Suite	0
\.


--
-- Data for Name: Packages; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Packages" ("Id", "Slug", "ProductType", "Details", "Status", "Title", "Subtitle", "Summary", "Description", "Category", "DestinationId", "Nights", "MinNights", "Adults", "Children", "PricingBasis", "BaseCurrency", "FromPriceMinor", "Featured", "SortOrder", "SeoTitle", "SeoDescription", "Version", "PublishedAt", "CreatedAt", "UpdatedAt") FROM stdin;
46a039e6-d50d-4f47-ac0e-30ab22d97535	giraffe-manor-solo-escape	HolidayPackage	\N	Published	Giraffe Manor Solo Escape	3 Nights / 4 Days for One Adult	An intimate, fully inclusive Giraffe Manor stay with meals, selected house drinks, Giraffe Centre access and qualifying transfers.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	3	3	1	0	PerParty	USD	698670	t	100	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
5daabefd-e115-48ab-a84e-33e6eb68f7f9	giraffe-manor-family-experience	HolidayPackage	\N	Published	Giraffe Manor Family Experience	5 Nights / 6 Days for Two Adults + Up to Two Children	A family stay in a two-bedroom suite with the Giraffe Manor fully inclusive experience.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	5	5	2	2	PerParty	USD	2657600	t	120	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	giraffe-manor-extended-family-package	HolidayPackage	\N	Published	Giraffe Manor Extended Family Package	5 Nights / 6 Days for Two Adults + Three Children	A family suite experience for a larger family, with a third child charged in addition to the suite minimum.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	5	5	2	3	PerParty	USD	2863350	t	130	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	giraffe-manor-signature-escape	HolidayPackage	\N	Published	Giraffe Manor Signature Escape	5 Nights / 6 Days for Two Adults	A fully inclusive stay for two with meals, selected house drinks, Giraffe Centre access and qualifying transfers.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	5	5	2	0	PerParty	USD	1413000	t	110	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
cbcb141f-458b-45b5-8d16-d1d4a883bbb8	giraffe-manor-family-and-friends-retreat-4-adults	HolidayPackage	\N	Published	Giraffe Manor Family and Friends Retreat (4 Adults)	7 Nights / 8 Days for Four Adults	A shared two-bedroom suite stay for four adults with the Giraffe Manor fully inclusive experience.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	7	7	4	0	PerParty	USD	4154220	t	150	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
d4d1b4e2-95d8-41fc-88a7-a25103292e81	giraffe-manor-family-and-friends-retreat-3-adults	HolidayPackage	\N	Published	Giraffe Manor Family and Friends Retreat (3 Adults)	7 Nights / 8 Days for Three Adults	A shared two-bedroom suite stay for three adults with the Giraffe Manor fully inclusive experience.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	7	7	3	0	PerParty	USD	3720640	t	140	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: Partners; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Partners" ("Id", "Slug", "Name", "Tagline", "LogoPath", "CreatedAt", "UpdatedAt") FROM stdin;
544979d3-cbf6-4ed4-95cf-c8138a167259	giraffe-manor	Giraffe Manor	An exclusive partnership. Extraordinary experiences.	\N	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: Properties; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Properties" ("Id", "Slug", "Name", "PartnerId", "DestinationId", "CreatedAt", "UpdatedAt") FROM stdin;
df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	giraffe-manor	Giraffe Manor	544979d3-cbf6-4ed4-95cf-c8138a167259	f1da7e79-5a02-49b0-902e-68145c23d5e3	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: PropertyMedia; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PropertyMedia" ("Id", "PropertyId", "Path", "Alt", "Caption", "Width", "Height", "VideoProvider", "VideoId", "VariantsReady", "SortKey", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: SeasonRanges; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."SeasonRanges" ("Id", "SeasonId", "StartDate", "EndDate") FROM stdin;
d03fef09-d5ca-4f27-817b-d5b8195f790a	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	2026-01-01	2026-12-31
\.


--
-- Data for Name: Seasons; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Seasons" ("Id", "Slug", "Name", "PartnerId", "CreatedAt", "UpdatedAt") FROM stdin;
2fab7c39-088e-4a6e-b2f2-f3c341b91e18	giraffe-manor-2026	2026	544979d3-cbf6-4ed4-95cf-c8138a167259	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: Staff; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Staff" ("Id", "Username", "Email", "PasswordHash", "Role", "IsActive", "FailedLoginAttempts", "LockedUntil", "LastLoginAt", "InvitedById", "CreatedAt", "UpdatedAt") FROM stdin;
e9705320-15ae-4dc4-acca-7a9e0872bd64	developers	developers@arlink28.com	AQAAAAIAAYagAAAAEN28Y1oOQVyd7LEyTVKvOPOaGIeNuH9VydTnOulydLx2FviEWzr4YAMu3gZDOkxlow==	SuperAdmin	t	0	\N	2026-10-16 02:24:16.271322+00	\N	2026-10-14 22:50:48.990239+00	2026-10-16 02:24:16.271351+00
\.


--
-- Data for Name: StaffTokens; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."StaffTokens" ("Id", "Type", "TokenHash", "Email", "RoleToAssign", "StaffId", "ExpiresAt", "UsedAt", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20261014210441_InitialCreate	10.0.0
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public.audit_logs ("Id", "ActorId", "Action", "EntityType", "EntityId", "Before", "After", "CreatedAt") FROM stdin;
9bb50cd7-bdf4-4250-b51c-3a699d5153a2	\N	Enquiry.Created	Enquiry	42638c3b-72ce-49d8-934b-b5237a420af4	\N	\N	2026-10-15 23:23:47.775762+00
2d3537d1-5efa-47fe-a83a-d4121d9f49bc	\N	Enquiry.Created	Enquiry	84c66f82-a9de-44b3-b72b-b8a5949891eb	\N	\N	2026-10-15 23:23:57.506447+00
2871d057-692e-4bf2-b21b-de97468f61c9	\N	Enquiry.Created	Enquiry	664f8419-53ce-4f70-8ef4-94b4c00a34b8	\N	\N	2026-10-15 23:27:48.92886+00
1c968bd3-6662-4c08-9970-d14e77d39d05	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:32:18.822304+00
db8a8988-8b4e-4bc6-9d6d-db91e78dc172	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:33:36.314447+00
2867a8a0-e03f-4ed1-84ec-4900b45e34f6	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:43:41.994324+00
b3b9f430-1b3a-430b-a00c-bb96cbddf48e	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:44:19.36717+00
acd034b8-1fad-4b97-bf51-104cf1e2ac91	\N	Enquiry.Created	Enquiry	dfa8b115-ea99-4bfe-b1db-cf397c311a66	\N	\N	2026-10-16 01:04:13.259535+00
c8e06ed8-94af-43fc-8625-f5f7ba42f6b8	\N	Enquiry.Created	Enquiry	3965844a-abd7-4635-b4a3-0909e29ff40f	\N	\N	2026-10-16 01:18:10.009061+00
a0ad905d-bb27-4046-9b6f-dd2e9f58d0f5	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:01:07.415804+00
0ee73261-a226-42e5-9403-8062e73dcf64	\N	seed.package.create	package	5daabefd-e115-48ab-a84e-33e6eb68f7f9	\N	{"Slug":"giraffe-manor-family-experience","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":2657600}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (2).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
1b9bdbea-569d-482b-a051-c5a47817ff2f	\N	seed.package.create	package	d4d1b4e2-95d8-41fc-88a7-a25103292e81	\N	{"Slug":"giraffe-manor-family-and-friends-retreat-3-adults","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":3720640}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (4).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
1d707fb6-2b77-4878-b495-cbcda3730307	\N	seed.package.create	package	46a039e6-d50d-4f47-ac0e-30ab22d97535	\N	{"Slug":"giraffe-manor-solo-escape","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":698670}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45.jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
c451fec6-365f-44e7-a4f9-95ac883935dc	\N	seed.package.create	package	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	\N	{"Slug":"giraffe-manor-signature-escape","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":1413000}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (1).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
d785f746-f30f-4f27-ab80-5aa9b25d1b67	\N	seed.package.create	package	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	\N	{"Slug":"giraffe-manor-family-and-friends-retreat-4-adults","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":4154220}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.46.jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
e66b5211-87c4-44e4-a107-4dd818b2c67b	\N	seed.package.create	package	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	\N	{"Slug":"giraffe-manor-extended-family-package","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":2863350}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (3).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
d71cf39a-6d76-490d-850e-f7318fdf1eb6	\N	Enquiry.Created	Enquiry	098ba038-42e1-4ef6-9a97-3d200c911146	\N	\N	2026-10-16 02:19:08.923976+00
587d659b-e88c-48da-b98d-996fb703e2eb	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:24:16.271649+00
14c58c9f-7652-4d2e-bc25-f5608cfbae71	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:29:12.121145+00
\.


--
-- Name: DestinationAttractions PK_DestinationAttractions; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."DestinationAttractions"
    ADD CONSTRAINT "PK_DestinationAttractions" PRIMARY KEY ("Id");


--
-- Name: Destinations PK_Destinations; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Destinations"
    ADD CONSTRAINT "PK_Destinations" PRIMARY KEY ("Id");


--
-- Name: Enquiries PK_Enquiries; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "PK_Enquiries" PRIMARY KEY ("Id");


--
-- Name: Features PK_Features; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Features"
    ADD CONSTRAINT "PK_Features" PRIMARY KEY ("Id");


--
-- Name: PackageAddOns PK_PackageAddOns; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageAddOns"
    ADD CONSTRAINT "PK_PackageAddOns" PRIMARY KEY ("Id");


--
-- Name: PackageFeatures PK_PackageFeatures; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "PK_PackageFeatures" PRIMARY KEY ("Id");


--
-- Name: PackageMedia PK_PackageMedia; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageMedia"
    ADD CONSTRAINT "PK_PackageMedia" PRIMARY KEY ("Id");


--
-- Name: PackageRates PK_PackageRates; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "PK_PackageRates" PRIMARY KEY ("Id");


--
-- Name: PackageStays PK_PackageStays; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "PK_PackageStays" PRIMARY KEY ("Id");


--
-- Name: Packages PK_Packages; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Packages"
    ADD CONSTRAINT "PK_Packages" PRIMARY KEY ("Id");


--
-- Name: Partners PK_Partners; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "PK_Partners" PRIMARY KEY ("Id");


--
-- Name: Properties PK_Properties; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "PK_Properties" PRIMARY KEY ("Id");


--
-- Name: PropertyMedia PK_PropertyMedia; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PropertyMedia"
    ADD CONSTRAINT "PK_PropertyMedia" PRIMARY KEY ("Id");


--
-- Name: SeasonRanges PK_SeasonRanges; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."SeasonRanges"
    ADD CONSTRAINT "PK_SeasonRanges" PRIMARY KEY ("Id");


--
-- Name: Seasons PK_Seasons; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Seasons"
    ADD CONSTRAINT "PK_Seasons" PRIMARY KEY ("Id");


--
-- Name: Staff PK_Staff; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "PK_Staff" PRIMARY KEY ("Id");


--
-- Name: StaffTokens PK_StaffTokens; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."StaffTokens"
    ADD CONSTRAINT "PK_StaffTokens" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: audit_logs PK_audit_logs; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "PK_audit_logs" PRIMARY KEY ("Id");


--
-- Name: IX_DestinationAttractions_DestinationId_SortOrder; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_DestinationAttractions_DestinationId_SortOrder" ON public."DestinationAttractions" USING btree ("DestinationId", "SortOrder");


--
-- Name: IX_Destinations_ParentId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Destinations_ParentId" ON public."Destinations" USING btree ("ParentId");


--
-- Name: IX_Destinations_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Destinations_Slug" ON public."Destinations" USING btree ("Slug");


--
-- Name: IX_Destinations_Status_Country_SortOrder; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Destinations_Status_Country_SortOrder" ON public."Destinations" USING btree ("Status", "Country", "SortOrder");


--
-- Name: IX_Enquiries_HandledById; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_HandledById" ON public."Enquiries" USING btree ("HandledById");


--
-- Name: IX_Enquiries_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_PackageId" ON public."Enquiries" USING btree ("PackageId");


--
-- Name: IX_Enquiries_Reference; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Enquiries_Reference" ON public."Enquiries" USING btree ("Reference");


--
-- Name: IX_Enquiries_Status_CreatedAt; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_Status_CreatedAt" ON public."Enquiries" USING btree ("Status", "CreatedAt");


--
-- Name: IX_Features_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Features_Slug" ON public."Features" USING btree ("Slug");


--
-- Name: IX_PackageAddOns_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageAddOns_PackageId" ON public."PackageAddOns" USING btree ("PackageId");


--
-- Name: IX_PackageFeatures_FeatureId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageFeatures_FeatureId" ON public."PackageFeatures" USING btree ("FeatureId");


--
-- Name: IX_PackageFeatures_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageFeatures_PackageId" ON public."PackageFeatures" USING btree ("PackageId");


--
-- Name: IX_PackageMedia_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageMedia_PackageId" ON public."PackageMedia" USING btree ("PackageId");


--
-- Name: IX_PackageMedia_Path; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PackageMedia_Path" ON public."PackageMedia" USING btree ("Path");


--
-- Name: IX_PackageRates_PackageId_SeasonId_Currency; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PackageRates_PackageId_SeasonId_Currency" ON public."PackageRates" USING btree ("PackageId", "SeasonId", "Currency");


--
-- Name: IX_PackageRates_SeasonId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageRates_SeasonId" ON public."PackageRates" USING btree ("SeasonId");


--
-- Name: IX_PackageStays_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageStays_PackageId" ON public."PackageStays" USING btree ("PackageId");


--
-- Name: IX_PackageStays_PropertyId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageStays_PropertyId" ON public."PackageStays" USING btree ("PropertyId");


--
-- Name: IX_Packages_DestinationId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_DestinationId" ON public."Packages" USING btree ("DestinationId");


--
-- Name: IX_Packages_Featured_SortOrder_Id; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_Featured_SortOrder_Id" ON public."Packages" USING btree ("Featured", "SortOrder", "Id");


--
-- Name: IX_Packages_ProductType_Status; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_ProductType_Status" ON public."Packages" USING btree ("ProductType", "Status");


--
-- Name: IX_Packages_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Packages_Slug" ON public."Packages" USING btree ("Slug");


--
-- Name: IX_Partners_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Partners_Slug" ON public."Partners" USING btree ("Slug");


--
-- Name: IX_Properties_DestinationId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Properties_DestinationId" ON public."Properties" USING btree ("DestinationId");


--
-- Name: IX_Properties_PartnerId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Properties_PartnerId" ON public."Properties" USING btree ("PartnerId");


--
-- Name: IX_Properties_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Properties_Slug" ON public."Properties" USING btree ("Slug");


--
-- Name: IX_PropertyMedia_Path; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PropertyMedia_Path" ON public."PropertyMedia" USING btree ("Path");


--
-- Name: IX_PropertyMedia_PropertyId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PropertyMedia_PropertyId" ON public."PropertyMedia" USING btree ("PropertyId");


--
-- Name: IX_SeasonRanges_SeasonId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_SeasonRanges_SeasonId" ON public."SeasonRanges" USING btree ("SeasonId");


--
-- Name: IX_Seasons_PartnerId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Seasons_PartnerId" ON public."Seasons" USING btree ("PartnerId");


--
-- Name: IX_Seasons_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Seasons_Slug" ON public."Seasons" USING btree ("Slug");


--
-- Name: IX_StaffTokens_Email_Type; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_StaffTokens_Email_Type" ON public."StaffTokens" USING btree ("Email", "Type");


--
-- Name: IX_StaffTokens_StaffId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_StaffTokens_StaffId" ON public."StaffTokens" USING btree ("StaffId");


--
-- Name: IX_StaffTokens_TokenHash; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_StaffTokens_TokenHash" ON public."StaffTokens" USING btree ("TokenHash");


--
-- Name: IX_Staff_Email; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Staff_Email" ON public."Staff" USING btree ("Email");


--
-- Name: IX_Staff_InvitedById; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Staff_InvitedById" ON public."Staff" USING btree ("InvitedById");


--
-- Name: IX_Staff_Username; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Staff_Username" ON public."Staff" USING btree ("Username");


--
-- Name: DestinationAttractions FK_DestinationAttractions_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."DestinationAttractions"
    ADD CONSTRAINT "FK_DestinationAttractions_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE CASCADE;


--
-- Name: Destinations FK_Destinations_Destinations_ParentId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Destinations"
    ADD CONSTRAINT "FK_Destinations_Destinations_ParentId" FOREIGN KEY ("ParentId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Enquiries FK_Enquiries_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "FK_Enquiries_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE SET NULL;


--
-- Name: Enquiries FK_Enquiries_Staff_HandledById; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "FK_Enquiries_Staff_HandledById" FOREIGN KEY ("HandledById") REFERENCES public."Staff"("Id") ON DELETE SET NULL;


--
-- Name: PackageAddOns FK_PackageAddOns_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageAddOns"
    ADD CONSTRAINT "FK_PackageAddOns_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageFeatures FK_PackageFeatures_Features_FeatureId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "FK_PackageFeatures_Features_FeatureId" FOREIGN KEY ("FeatureId") REFERENCES public."Features"("Id") ON DELETE SET NULL;


--
-- Name: PackageFeatures FK_PackageFeatures_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "FK_PackageFeatures_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageMedia FK_PackageMedia_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageMedia"
    ADD CONSTRAINT "FK_PackageMedia_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageRates FK_PackageRates_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "FK_PackageRates_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageRates FK_PackageRates_Seasons_SeasonId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "FK_PackageRates_Seasons_SeasonId" FOREIGN KEY ("SeasonId") REFERENCES public."Seasons"("Id") ON DELETE RESTRICT;


--
-- Name: PackageStays FK_PackageStays_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "FK_PackageStays_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageStays FK_PackageStays_Properties_PropertyId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "FK_PackageStays_Properties_PropertyId" FOREIGN KEY ("PropertyId") REFERENCES public."Properties"("Id") ON DELETE RESTRICT;


--
-- Name: Packages FK_Packages_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Packages"
    ADD CONSTRAINT "FK_Packages_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Properties FK_Properties_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "FK_Properties_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Properties FK_Properties_Partners_PartnerId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "FK_Properties_Partners_PartnerId" FOREIGN KEY ("PartnerId") REFERENCES public."Partners"("Id") ON DELETE SET NULL;


--
-- Name: PropertyMedia FK_PropertyMedia_Properties_PropertyId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PropertyMedia"
    ADD CONSTRAINT "FK_PropertyMedia_Properties_PropertyId" FOREIGN KEY ("PropertyId") REFERENCES public."Properties"("Id") ON DELETE CASCADE;


--
-- Name: SeasonRanges FK_SeasonRanges_Seasons_SeasonId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."SeasonRanges"
    ADD CONSTRAINT "FK_SeasonRanges_Seasons_SeasonId" FOREIGN KEY ("SeasonId") REFERENCES public."Seasons"("Id") ON DELETE CASCADE;


--
-- Name: Seasons FK_Seasons_Partners_PartnerId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Seasons"
    ADD CONSTRAINT "FK_Seasons_Partners_PartnerId" FOREIGN KEY ("PartnerId") REFERENCES public."Partners"("Id") ON DELETE SET NULL;


--
-- Name: StaffTokens FK_StaffTokens_Staff_StaffId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."StaffTokens"
    ADD CONSTRAINT "FK_StaffTokens_Staff_StaffId" FOREIGN KEY ("StaffId") REFERENCES public."Staff"("Id") ON DELETE CASCADE;


--
-- Name: Staff FK_Staff_Staff_InvitedById; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "FK_Staff_Staff_InvitedById" FOREIGN KEY ("InvitedById") REFERENCES public."Staff"("Id") ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 14g1aSer1w9DoaPmGgc2ylqhp2hlSOdbSLUl4k7rUOcHruKdoDZ48Gim1UY5CHl

