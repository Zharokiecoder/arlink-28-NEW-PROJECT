--
-- PostgreSQL database dump
--

\restrict qYjsCSBetqW2QgLxli9iqFhUzpSTgmxOxPBCmy6IPYVXcueoy3VbuIfpkNGJaqs

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: DestinationAttractions; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."DestinationAttractions" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "DestinationId" uuid NOT NULL,
    "Name" character varying(120) NOT NULL,
    "Summary" character varying(300),
    "PhotoPath" character varying(255),
    "PhotoAlt" character varying(250),
    "PhotoCredit" character varying(250),
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."DestinationAttractions" OWNER TO arlink28;

--
-- Name: Destinations; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Destinations" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Country" character(2) NOT NULL,
    "Kind" character varying(20) NOT NULL,
    "Status" character varying(20) NOT NULL,
    "ParentId" uuid,
    "Tagline" character varying(160),
    "Summary" character varying(400),
    "Description" text,
    "BestTimeToVisit" character varying(200),
    "HeroPath" character varying(255),
    "HeroAlt" character varying(250),
    "HeroCredit" character varying(250),
    "Latitude" double precision,
    "Longitude" double precision,
    "SortOrder" integer NOT NULL,
    "PublishedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Destinations" OWNER TO arlink28;

--
-- Name: Enquiries; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Enquiries" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Reference" character varying(20) NOT NULL,
    "Type" character varying(20) NOT NULL,
    "Status" character varying(20) NOT NULL,
    "PackageId" uuid,
    "PackageTitle" character varying(200),
    "CheckIn" date,
    "Nights" integer,
    "QuotedTotalMinor" bigint,
    "Currency" character(3),
    "Name" character varying(120) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "Phone" character varying(40),
    "Subject" character varying(200),
    "Message" character varying(4000),
    "ConsentAt" timestamp with time zone NOT NULL,
    "SourceUrl" character varying(500),
    "HandledById" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Enquiries" OWNER TO arlink28;

--
-- Name: Features; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Features" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Label" character varying(200) NOT NULL,
    "Icon" character varying(100),
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Features" OWNER TO arlink28;

--
-- Name: PackageAddOns; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageAddOns" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Name" character varying(200) NOT NULL,
    "Description" character varying(500),
    "Unit" character varying(20) NOT NULL,
    "Currency" character(3) NOT NULL,
    "PriceMinor" bigint NOT NULL,
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageAddOns" OWNER TO arlink28;

--
-- Name: PackageFeatures; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageFeatures" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Section" character varying(30) NOT NULL,
    "FeatureId" uuid,
    "LabelOverride" character varying(200),
    "Footnote" character varying(500),
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageFeatures" OWNER TO arlink28;

--
-- Name: PackageMedia; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageMedia" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Role" character varying(20) NOT NULL,
    "Path" character varying(500) NOT NULL,
    "Alt" character varying(250),
    "Caption" character varying(500),
    "Width" integer,
    "Height" integer,
    "VideoProvider" character varying(20),
    "VideoId" character varying(100),
    "VariantsReady" boolean NOT NULL,
    "SortKey" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PackageMedia" OWNER TO arlink28;

--
-- Name: PackageRates; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageRates" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "SeasonId" uuid NOT NULL,
    "Currency" character(3) NOT NULL,
    "PriceMinor" bigint NOT NULL,
    "ExtraNightPriceMinor" bigint
);


ALTER TABLE public."PackageRates" OWNER TO arlink28;

--
-- Name: PackageStays; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageStays" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "PropertyId" uuid NOT NULL,
    "Nights" integer NOT NULL,
    "RoomType" character varying(100),
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageStays" OWNER TO arlink28;

--
-- Name: Packages; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Packages" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "ProductType" character varying(20) NOT NULL,
    "Details" jsonb,
    "Status" character varying(20) NOT NULL,
    "Title" character varying(200) NOT NULL,
    "Subtitle" character varying(200),
    "Summary" character varying(500),
    "Description" text,
    "Category" character varying(50) NOT NULL,
    "DestinationId" uuid NOT NULL,
    "Nights" integer NOT NULL,
    "MinNights" integer NOT NULL,
    "Adults" integer NOT NULL,
    "Children" integer NOT NULL,
    "PricingBasis" character varying(20) NOT NULL,
    "BaseCurrency" character(3) NOT NULL,
    "FromPriceMinor" bigint,
    "Featured" boolean NOT NULL,
    "SortOrder" integer NOT NULL,
    "SeoTitle" character varying(70),
    "SeoDescription" character varying(160),
    "Version" integer NOT NULL,
    "PublishedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Packages" OWNER TO arlink28;

--
-- Name: Partners; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Partners" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Tagline" character varying(200),
    "LogoPath" character varying(500),
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Partners" OWNER TO arlink28;

--
-- Name: Properties; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Properties" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(200) NOT NULL,
    "PartnerId" uuid,
    "DestinationId" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Properties" OWNER TO arlink28;

--
-- Name: PropertyMedia; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PropertyMedia" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PropertyId" uuid NOT NULL,
    "Path" character varying(500) NOT NULL,
    "Alt" character varying(250),
    "Caption" character varying(500),
    "Width" integer,
    "Height" integer,
    "VideoProvider" character varying(20),
    "VideoId" character varying(100),
    "VariantsReady" boolean NOT NULL,
    "SortKey" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PropertyMedia" OWNER TO arlink28;

--
-- Name: SeasonRanges; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."SeasonRanges" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "SeasonId" uuid NOT NULL,
    "StartDate" date NOT NULL,
    "EndDate" date NOT NULL
);


ALTER TABLE public."SeasonRanges" OWNER TO arlink28;

--
-- Name: Seasons; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Seasons" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "PartnerId" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Seasons" OWNER TO arlink28;

--
-- Name: Staff; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Staff" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Username" character varying(50) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "PasswordHash" text NOT NULL,
    "Role" character varying(20) NOT NULL,
    "IsActive" boolean NOT NULL,
    "FailedLoginAttempts" integer NOT NULL,
    "LockedUntil" timestamp with time zone,
    "LastLoginAt" timestamp with time zone,
    "InvitedById" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Staff" OWNER TO arlink28;

--
-- Name: StaffTokens; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."StaffTokens" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Type" character varying(20) NOT NULL,
    "TokenHash" character varying(64) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "RoleToAssign" character varying(20),
    "StaffId" uuid,
    "ExpiresAt" timestamp with time zone NOT NULL,
    "UsedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."StaffTokens" OWNER TO arlink28;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO arlink28;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public.audit_logs (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "ActorId" character varying(36),
    "Action" character varying(100) NOT NULL,
    "EntityType" character varying(100) NOT NULL,
    "EntityId" character varying(36) NOT NULL,
    "Before" text,
    "After" text,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO arlink28;

--
-- Data for Name: DestinationAttractions; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."DestinationAttractions" ("Id", "DestinationId", "Name", "Summary", "PhotoPath", "PhotoAlt", "PhotoCredit", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Destinations; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Destinations" ("Id", "Slug", "Name", "Country", "Kind", "Status", "ParentId", "Tagline", "Summary", "Description", "BestTimeToVisit", "HeroPath", "HeroAlt", "HeroCredit", "Latitude", "Longitude", "SortOrder", "PublishedAt", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Enquiries; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Enquiries" ("Id", "Reference", "Type", "Status", "PackageId", "PackageTitle", "CheckIn", "Nights", "QuotedTotalMinor", "Currency", "Name", "Email", "Phone", "Subject", "Message", "ConsentAt", "SourceUrl", "HandledById", "CreatedAt", "UpdatedAt") FROM stdin;
42638c3b-72ce-49d8-934b-b5237a420af4	ENQ-2026-0001	General	New	\N	\N	\N	\N	\N	\N	Playwright test 23:23:46 (ignore)	developers@arlink28.com	+44 7000 000000	Mail test 23:23:46 - contact form	Automated test of the contact form email routing. Please ignore.	2026-10-15 23:23:47.775762+00	/contact	\N	2026-10-15 23:23:47.775762+00	2026-10-15 23:23:47.775762+00
84c66f82-a9de-44b3-b72b-b8a5949891eb	ENQ-2026-0002	Booking	New	\N	\N	\N	\N	\N	\N	Playwright test 23:23:46 (ignore)	developers@arlink28.com	+44 7000 000000	Flight quote: Mail test destination	Service: Flight\nDestination: Mail test destination\nTravellers: 1 person\n\nAutomated test of the quote email routing 23:23:46. Please ignore.	2026-10-15 23:23:57.506447+00	/quote	\N	2026-10-15 23:23:57.506447+00	2026-10-15 23:23:57.506447+00
664f8419-53ce-4f70-8ef4-94b4c00a34b8	ENQ-2026-0003	Booking	New	\N	\N	\N	\N	\N	\N	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	Hotel reservation quote: Cape Town	Service: Hotel reservation\nDestination: Cape Town\nTravellers: 1 person\n\ntesting ignore this	2026-10-15 23:27:48.92886+00	/quote	\N	2026-10-15 23:27:48.92886+00	2026-10-15 23:27:48.92886+00
dfa8b115-ea99-4bfe-b1db-cf397c311a66	ENQ-2026-0004	General	New	\N	\N	\N	\N	\N	\N	Playwright email test	developers@arlink28.com	\N	Email test 2026-10-16T01:04:08.205Z	Automated check that enquiry emails send from production. Safe to delete.	2026-10-16 01:04:13.259535+00	/contact	\N	2026-10-16 01:04:13.259535+00	2026-10-16 01:04:13.259535+00
3965844a-abd7-4635-b4a3-0909e29ff40f	ENQ-2026-0005	Booking	New	\N	\N	\N	\N	\N	\N	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	Flight quote: Cape Town	Service: Flight\nDestination: Cape Town\nTravellers: 1 person\n\ntesting	2026-10-16 01:18:10.009061+00	/quote	\N	2026-10-16 01:18:10.009061+00	2026-10-16 01:18:10.009061+00
\.


--
-- Data for Name: Features; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Features" ("Id", "Slug", "Label", "Icon", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: PackageAddOns; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageAddOns" ("Id", "PackageId", "Name", "Description", "Unit", "Currency", "PriceMinor", "SortOrder") FROM stdin;
\.


--
-- Data for Name: PackageFeatures; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageFeatures" ("Id", "PackageId", "Section", "FeatureId", "LabelOverride", "Footnote", "SortOrder") FROM stdin;
\.


--
-- Data for Name: PackageMedia; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageMedia" ("Id", "PackageId", "Role", "Path", "Alt", "Caption", "Width", "Height", "VideoProvider", "VideoId", "VariantsReady", "SortKey", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: PackageRates; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageRates" ("Id", "PackageId", "SeasonId", "Currency", "PriceMinor", "ExtraNightPriceMinor") FROM stdin;
\.


--
-- Data for Name: PackageStays; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageStays" ("Id", "PackageId", "PropertyId", "Nights", "RoomType", "SortOrder") FROM stdin;
\.


--
-- Data for Name: Packages; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Packages" ("Id", "Slug", "ProductType", "Details", "Status", "Title", "Subtitle", "Summary", "Description", "Category", "DestinationId", "Nights", "MinNights", "Adults", "Children", "PricingBasis", "BaseCurrency", "FromPriceMinor", "Featured", "SortOrder", "SeoTitle", "SeoDescription", "Version", "PublishedAt", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Partners; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Partners" ("Id", "Slug", "Name", "Tagline", "LogoPath", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Properties; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Properties" ("Id", "Slug", "Name", "PartnerId", "DestinationId", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: PropertyMedia; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PropertyMedia" ("Id", "PropertyId", "Path", "Alt", "Caption", "Width", "Height", "VideoProvider", "VideoId", "VariantsReady", "SortKey", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: SeasonRanges; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."SeasonRanges" ("Id", "SeasonId", "StartDate", "EndDate") FROM stdin;
\.


--
-- Data for Name: Seasons; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Seasons" ("Id", "Slug", "Name", "PartnerId", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Staff; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Staff" ("Id", "Username", "Email", "PasswordHash", "Role", "IsActive", "FailedLoginAttempts", "LockedUntil", "LastLoginAt", "InvitedById", "CreatedAt", "UpdatedAt") FROM stdin;
e9705320-15ae-4dc4-acca-7a9e0872bd64	developers	developers@arlink28.com	AQAAAAIAAYagAAAAEN28Y1oOQVyd7LEyTVKvOPOaGIeNuH9VydTnOulydLx2FviEWzr4YAMu3gZDOkxlow==	SuperAdmin	t	0	\N	2026-10-16 02:01:07.415078+00	\N	2026-10-14 22:50:48.990239+00	2026-10-16 02:01:07.415099+00
\.


--
-- Data for Name: StaffTokens; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."StaffTokens" ("Id", "Type", "TokenHash", "Email", "RoleToAssign", "StaffId", "ExpiresAt", "UsedAt", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20261014210441_InitialCreate	10.0.0
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public.audit_logs ("Id", "ActorId", "Action", "EntityType", "EntityId", "Before", "After", "CreatedAt") FROM stdin;
9bb50cd7-bdf4-4250-b51c-3a699d5153a2	\N	Enquiry.Created	Enquiry	42638c3b-72ce-49d8-934b-b5237a420af4	\N	\N	2026-10-15 23:23:47.775762+00
2d3537d1-5efa-47fe-a83a-d4121d9f49bc	\N	Enquiry.Created	Enquiry	84c66f82-a9de-44b3-b72b-b8a5949891eb	\N	\N	2026-10-15 23:23:57.506447+00
2871d057-692e-4bf2-b21b-de97468f61c9	\N	Enquiry.Created	Enquiry	664f8419-53ce-4f70-8ef4-94b4c00a34b8	\N	\N	2026-10-15 23:27:48.92886+00
1c968bd3-6662-4c08-9970-d14e77d39d05	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:32:18.822304+00
db8a8988-8b4e-4bc6-9d6d-db91e78dc172	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:33:36.314447+00
2867a8a0-e03f-4ed1-84ec-4900b45e34f6	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:43:41.994324+00
b3b9f430-1b3a-430b-a00c-bb96cbddf48e	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:44:19.36717+00
acd034b8-1fad-4b97-bf51-104cf1e2ac91	\N	Enquiry.Created	Enquiry	dfa8b115-ea99-4bfe-b1db-cf397c311a66	\N	\N	2026-10-16 01:04:13.259535+00
c8e06ed8-94af-43fc-8625-f5f7ba42f6b8	\N	Enquiry.Created	Enquiry	3965844a-abd7-4635-b4a3-0909e29ff40f	\N	\N	2026-10-16 01:18:10.009061+00
a0ad905d-bb27-4046-9b6f-dd2e9f58d0f5	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:01:07.415804+00
\.


--
-- Name: DestinationAttractions PK_DestinationAttractions; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."DestinationAttractions"
    ADD CONSTRAINT "PK_DestinationAttractions" PRIMARY KEY ("Id");


--
-- Name: Destinations PK_Destinations; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Destinations"
    ADD CONSTRAINT "PK_Destinations" PRIMARY KEY ("Id");


--
-- Name: Enquiries PK_Enquiries; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "PK_Enquiries" PRIMARY KEY ("Id");


--
-- Name: Features PK_Features; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Features"
    ADD CONSTRAINT "PK_Features" PRIMARY KEY ("Id");


--
-- Name: PackageAddOns PK_PackageAddOns; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageAddOns"
    ADD CONSTRAINT "PK_PackageAddOns" PRIMARY KEY ("Id");


--
-- Name: PackageFeatures PK_PackageFeatures; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "PK_PackageFeatures" PRIMARY KEY ("Id");


--
-- Name: PackageMedia PK_PackageMedia; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageMedia"
    ADD CONSTRAINT "PK_PackageMedia" PRIMARY KEY ("Id");


--
-- Name: PackageRates PK_PackageRates; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "PK_PackageRates" PRIMARY KEY ("Id");


--
-- Name: PackageStays PK_PackageStays; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "PK_PackageStays" PRIMARY KEY ("Id");


--
-- Name: Packages PK_Packages; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Packages"
    ADD CONSTRAINT "PK_Packages" PRIMARY KEY ("Id");


--
-- Name: Partners PK_Partners; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "PK_Partners" PRIMARY KEY ("Id");


--
-- Name: Properties PK_Properties; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "PK_Properties" PRIMARY KEY ("Id");


--
-- Name: PropertyMedia PK_PropertyMedia; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PropertyMedia"
    ADD CONSTRAINT "PK_PropertyMedia" PRIMARY KEY ("Id");


--
-- Name: SeasonRanges PK_SeasonRanges; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."SeasonRanges"
    ADD CONSTRAINT "PK_SeasonRanges" PRIMARY KEY ("Id");


--
-- Name: Seasons PK_Seasons; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Seasons"
    ADD CONSTRAINT "PK_Seasons" PRIMARY KEY ("Id");


--
-- Name: Staff PK_Staff; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "PK_Staff" PRIMARY KEY ("Id");


--
-- Name: StaffTokens PK_StaffTokens; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."StaffTokens"
    ADD CONSTRAINT "PK_StaffTokens" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: audit_logs PK_audit_logs; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "PK_audit_logs" PRIMARY KEY ("Id");


--
-- Name: IX_DestinationAttractions_DestinationId_SortOrder; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_DestinationAttractions_DestinationId_SortOrder" ON public."DestinationAttractions" USING btree ("DestinationId", "SortOrder");


--
-- Name: IX_Destinations_ParentId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Destinations_ParentId" ON public."Destinations" USING btree ("ParentId");


--
-- Name: IX_Destinations_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Destinations_Slug" ON public."Destinations" USING btree ("Slug");


--
-- Name: IX_Destinations_Status_Country_SortOrder; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Destinations_Status_Country_SortOrder" ON public."Destinations" USING btree ("Status", "Country", "SortOrder");


--
-- Name: IX_Enquiries_HandledById; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_HandledById" ON public."Enquiries" USING btree ("HandledById");


--
-- Name: IX_Enquiries_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_PackageId" ON public."Enquiries" USING btree ("PackageId");


--
-- Name: IX_Enquiries_Reference; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Enquiries_Reference" ON public."Enquiries" USING btree ("Reference");


--
-- Name: IX_Enquiries_Status_CreatedAt; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_Status_CreatedAt" ON public."Enquiries" USING btree ("Status", "CreatedAt");


--
-- Name: IX_Features_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Features_Slug" ON public."Features" USING btree ("Slug");


--
-- Name: IX_PackageAddOns_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageAddOns_PackageId" ON public."PackageAddOns" USING btree ("PackageId");


--
-- Name: IX_PackageFeatures_FeatureId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageFeatures_FeatureId" ON public."PackageFeatures" USING btree ("FeatureId");


--
-- Name: IX_PackageFeatures_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageFeatures_PackageId" ON public."PackageFeatures" USING btree ("PackageId");


--
-- Name: IX_PackageMedia_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageMedia_PackageId" ON public."PackageMedia" USING btree ("PackageId");


--
-- Name: IX_PackageMedia_Path; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PackageMedia_Path" ON public."PackageMedia" USING btree ("Path");


--
-- Name: IX_PackageRates_PackageId_SeasonId_Currency; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PackageRates_PackageId_SeasonId_Currency" ON public."PackageRates" USING btree ("PackageId", "SeasonId", "Currency");


--
-- Name: IX_PackageRates_SeasonId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageRates_SeasonId" ON public."PackageRates" USING btree ("SeasonId");


--
-- Name: IX_PackageStays_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageStays_PackageId" ON public."PackageStays" USING btree ("PackageId");


--
-- Name: IX_PackageStays_PropertyId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageStays_PropertyId" ON public."PackageStays" USING btree ("PropertyId");


--
-- Name: IX_Packages_DestinationId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_DestinationId" ON public."Packages" USING btree ("DestinationId");


--
-- Name: IX_Packages_Featured_SortOrder_Id; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_Featured_SortOrder_Id" ON public."Packages" USING btree ("Featured", "SortOrder", "Id");


--
-- Name: IX_Packages_ProductType_Status; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_ProductType_Status" ON public."Packages" USING btree ("ProductType", "Status");


--
-- Name: IX_Packages_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Packages_Slug" ON public."Packages" USING btree ("Slug");


--
-- Name: IX_Partners_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Partners_Slug" ON public."Partners" USING btree ("Slug");


--
-- Name: IX_Properties_DestinationId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Properties_DestinationId" ON public."Properties" USING btree ("DestinationId");


--
-- Name: IX_Properties_PartnerId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Properties_PartnerId" ON public."Properties" USING btree ("PartnerId");


--
-- Name: IX_Properties_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Properties_Slug" ON public."Properties" USING btree ("Slug");


--
-- Name: IX_PropertyMedia_Path; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PropertyMedia_Path" ON public."PropertyMedia" USING btree ("Path");


--
-- Name: IX_PropertyMedia_PropertyId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PropertyMedia_PropertyId" ON public."PropertyMedia" USING btree ("PropertyId");


--
-- Name: IX_SeasonRanges_SeasonId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_SeasonRanges_SeasonId" ON public."SeasonRanges" USING btree ("SeasonId");


--
-- Name: IX_Seasons_PartnerId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Seasons_PartnerId" ON public."Seasons" USING btree ("PartnerId");


--
-- Name: IX_Seasons_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Seasons_Slug" ON public."Seasons" USING btree ("Slug");


--
-- Name: IX_StaffTokens_Email_Type; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_StaffTokens_Email_Type" ON public."StaffTokens" USING btree ("Email", "Type");


--
-- Name: IX_StaffTokens_StaffId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_StaffTokens_StaffId" ON public."StaffTokens" USING btree ("StaffId");


--
-- Name: IX_StaffTokens_TokenHash; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_StaffTokens_TokenHash" ON public."StaffTokens" USING btree ("TokenHash");


--
-- Name: IX_Staff_Email; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Staff_Email" ON public."Staff" USING btree ("Email");


--
-- Name: IX_Staff_InvitedById; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Staff_InvitedById" ON public."Staff" USING btree ("InvitedById");


--
-- Name: IX_Staff_Username; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Staff_Username" ON public."Staff" USING btree ("Username");


--
-- Name: DestinationAttractions FK_DestinationAttractions_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."DestinationAttractions"
    ADD CONSTRAINT "FK_DestinationAttractions_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE CASCADE;


--
-- Name: Destinations FK_Destinations_Destinations_ParentId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Destinations"
    ADD CONSTRAINT "FK_Destinations_Destinations_ParentId" FOREIGN KEY ("ParentId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Enquiries FK_Enquiries_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "FK_Enquiries_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE SET NULL;


--
-- Name: Enquiries FK_Enquiries_Staff_HandledById; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "FK_Enquiries_Staff_HandledById" FOREIGN KEY ("HandledById") REFERENCES public."Staff"("Id") ON DELETE SET NULL;


--
-- Name: PackageAddOns FK_PackageAddOns_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageAddOns"
    ADD CONSTRAINT "FK_PackageAddOns_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageFeatures FK_PackageFeatures_Features_FeatureId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "FK_PackageFeatures_Features_FeatureId" FOREIGN KEY ("FeatureId") REFERENCES public."Features"("Id") ON DELETE SET NULL;


--
-- Name: PackageFeatures FK_PackageFeatures_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "FK_PackageFeatures_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageMedia FK_PackageMedia_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageMedia"
    ADD CONSTRAINT "FK_PackageMedia_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageRates FK_PackageRates_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "FK_PackageRates_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageRates FK_PackageRates_Seasons_SeasonId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "FK_PackageRates_Seasons_SeasonId" FOREIGN KEY ("SeasonId") REFERENCES public."Seasons"("Id") ON DELETE RESTRICT;


--
-- Name: PackageStays FK_PackageStays_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "FK_PackageStays_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageStays FK_PackageStays_Properties_PropertyId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "FK_PackageStays_Properties_PropertyId" FOREIGN KEY ("PropertyId") REFERENCES public."Properties"("Id") ON DELETE RESTRICT;


--
-- Name: Packages FK_Packages_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Packages"
    ADD CONSTRAINT "FK_Packages_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Properties FK_Properties_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "FK_Properties_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Properties FK_Properties_Partners_PartnerId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "FK_Properties_Partners_PartnerId" FOREIGN KEY ("PartnerId") REFERENCES public."Partners"("Id") ON DELETE SET NULL;


--
-- Name: PropertyMedia FK_PropertyMedia_Properties_PropertyId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PropertyMedia"
    ADD CONSTRAINT "FK_PropertyMedia_Properties_PropertyId" FOREIGN KEY ("PropertyId") REFERENCES public."Properties"("Id") ON DELETE CASCADE;


--
-- Name: SeasonRanges FK_SeasonRanges_Seasons_SeasonId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."SeasonRanges"
    ADD CONSTRAINT "FK_SeasonRanges_Seasons_SeasonId" FOREIGN KEY ("SeasonId") REFERENCES public."Seasons"("Id") ON DELETE CASCADE;


--
-- Name: Seasons FK_Seasons_Partners_PartnerId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Seasons"
    ADD CONSTRAINT "FK_Seasons_Partners_PartnerId" FOREIGN KEY ("PartnerId") REFERENCES public."Partners"("Id") ON DELETE SET NULL;


--
-- Name: StaffTokens FK_StaffTokens_Staff_StaffId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."StaffTokens"
    ADD CONSTRAINT "FK_StaffTokens_Staff_StaffId" FOREIGN KEY ("StaffId") REFERENCES public."Staff"("Id") ON DELETE CASCADE;


--
-- Name: Staff FK_Staff_Staff_InvitedById; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "FK_Staff_Staff_InvitedById" FOREIGN KEY ("InvitedById") REFERENCES public."Staff"("Id") ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict qYjsCSBetqW2QgLxli9iqFhUzpSTgmxOxPBCmy6IPYVXcueoy3VbuIfpkNGJaqs

