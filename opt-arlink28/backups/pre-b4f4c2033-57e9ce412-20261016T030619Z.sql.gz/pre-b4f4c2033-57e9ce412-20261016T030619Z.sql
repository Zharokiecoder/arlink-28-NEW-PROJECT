--
-- PostgreSQL database dump
--

\restrict JeJ6T8eaUsECBztrsNBhFifYsYPiawFbXrQJxBjGaeyHIYMRmTmc8vhPCW0VCbQ

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: DestinationAttractions; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."DestinationAttractions" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "DestinationId" uuid NOT NULL,
    "Name" character varying(120) NOT NULL,
    "Summary" character varying(300),
    "PhotoPath" character varying(255),
    "PhotoAlt" character varying(250),
    "PhotoCredit" character varying(250),
    "SortOrder" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."DestinationAttractions" OWNER TO arlink28;

--
-- Name: Destinations; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Destinations" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Country" character(2) NOT NULL,
    "Kind" character varying(20) NOT NULL,
    "Status" character varying(20) NOT NULL,
    "ParentId" uuid,
    "Tagline" character varying(160),
    "Summary" character varying(400),
    "Description" text,
    "BestTimeToVisit" character varying(200),
    "HeroPath" character varying(255),
    "HeroAlt" character varying(250),
    "HeroCredit" character varying(250),
    "Latitude" double precision,
    "Longitude" double precision,
    "SortOrder" integer NOT NULL,
    "PublishedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Destinations" OWNER TO arlink28;

--
-- Name: Enquiries; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Enquiries" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Reference" character varying(20) NOT NULL,
    "Type" character varying(20) NOT NULL,
    "Status" character varying(20) NOT NULL,
    "PackageId" uuid,
    "PackageTitle" character varying(200),
    "CheckIn" date,
    "Nights" integer,
    "QuotedTotalMinor" bigint,
    "Currency" character(3),
    "Name" character varying(120) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "Phone" character varying(40),
    "Subject" character varying(200),
    "Message" character varying(4000),
    "ConsentAt" timestamp with time zone NOT NULL,
    "SourceUrl" character varying(500),
    "HandledById" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Enquiries" OWNER TO arlink28;

--
-- Name: Features; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Features" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Label" character varying(200) NOT NULL,
    "Icon" character varying(100),
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Features" OWNER TO arlink28;

--
-- Name: PackageAddOns; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageAddOns" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Name" character varying(200) NOT NULL,
    "Description" character varying(500),
    "Unit" character varying(20) NOT NULL,
    "Currency" character(3) NOT NULL,
    "PriceMinor" bigint NOT NULL,
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageAddOns" OWNER TO arlink28;

--
-- Name: PackageFeatures; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageFeatures" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Section" character varying(30) NOT NULL,
    "FeatureId" uuid,
    "LabelOverride" character varying(200),
    "Footnote" character varying(500),
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageFeatures" OWNER TO arlink28;

--
-- Name: PackageMedia; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageMedia" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "Role" character varying(20) NOT NULL,
    "Path" character varying(500) NOT NULL,
    "Alt" character varying(250),
    "Caption" character varying(500),
    "Width" integer,
    "Height" integer,
    "VideoProvider" character varying(20),
    "VideoId" character varying(100),
    "VariantsReady" boolean NOT NULL,
    "SortKey" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PackageMedia" OWNER TO arlink28;

--
-- Name: PackageRates; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageRates" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "SeasonId" uuid NOT NULL,
    "Currency" character(3) NOT NULL,
    "PriceMinor" bigint NOT NULL,
    "ExtraNightPriceMinor" bigint
);


ALTER TABLE public."PackageRates" OWNER TO arlink28;

--
-- Name: PackageStays; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PackageStays" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PackageId" uuid NOT NULL,
    "PropertyId" uuid NOT NULL,
    "Nights" integer NOT NULL,
    "RoomType" character varying(100),
    "SortOrder" integer NOT NULL
);


ALTER TABLE public."PackageStays" OWNER TO arlink28;

--
-- Name: Packages; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Packages" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "ProductType" character varying(20) NOT NULL,
    "Details" jsonb,
    "Status" character varying(20) NOT NULL,
    "Title" character varying(200) NOT NULL,
    "Subtitle" character varying(200),
    "Summary" character varying(500),
    "Description" text,
    "Category" character varying(50) NOT NULL,
    "DestinationId" uuid NOT NULL,
    "Nights" integer NOT NULL,
    "MinNights" integer NOT NULL,
    "Adults" integer NOT NULL,
    "Children" integer NOT NULL,
    "PricingBasis" character varying(20) NOT NULL,
    "BaseCurrency" character(3) NOT NULL,
    "FromPriceMinor" bigint,
    "Featured" boolean NOT NULL,
    "SortOrder" integer NOT NULL,
    "SeoTitle" character varying(70),
    "SeoDescription" character varying(160),
    "Version" integer NOT NULL,
    "PublishedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Packages" OWNER TO arlink28;

--
-- Name: Partners; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Partners" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "Tagline" character varying(200),
    "LogoPath" character varying(500),
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Partners" OWNER TO arlink28;

--
-- Name: Properties; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Properties" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(200) NOT NULL,
    "PartnerId" uuid,
    "DestinationId" uuid NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Properties" OWNER TO arlink28;

--
-- Name: PropertyMedia; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."PropertyMedia" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "PropertyId" uuid NOT NULL,
    "Path" character varying(500) NOT NULL,
    "Alt" character varying(250),
    "Caption" character varying(500),
    "Width" integer,
    "Height" integer,
    "VideoProvider" character varying(20),
    "VideoId" character varying(100),
    "VariantsReady" boolean NOT NULL,
    "SortKey" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."PropertyMedia" OWNER TO arlink28;

--
-- Name: SeasonRanges; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."SeasonRanges" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "SeasonId" uuid NOT NULL,
    "StartDate" date NOT NULL,
    "EndDate" date NOT NULL
);


ALTER TABLE public."SeasonRanges" OWNER TO arlink28;

--
-- Name: Seasons; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Seasons" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Slug" character varying(100) NOT NULL,
    "Name" character varying(100) NOT NULL,
    "PartnerId" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Seasons" OWNER TO arlink28;

--
-- Name: Staff; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."Staff" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Username" character varying(50) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "PasswordHash" text NOT NULL,
    "Role" character varying(20) NOT NULL,
    "IsActive" boolean NOT NULL,
    "FailedLoginAttempts" integer NOT NULL,
    "LockedUntil" timestamp with time zone,
    "LastLoginAt" timestamp with time zone,
    "InvitedById" uuid,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Staff" OWNER TO arlink28;

--
-- Name: StaffTokens; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."StaffTokens" (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "Type" character varying(20) NOT NULL,
    "TokenHash" character varying(64) NOT NULL,
    "Email" character varying(200) NOT NULL,
    "RoleToAssign" character varying(20),
    "StaffId" uuid,
    "ExpiresAt" timestamp with time zone NOT NULL,
    "UsedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."StaffTokens" OWNER TO arlink28;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO arlink28;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: arlink28
--

CREATE TABLE public.audit_logs (
    "Id" uuid DEFAULT gen_random_uuid() NOT NULL,
    "ActorId" character varying(36),
    "Action" character varying(100) NOT NULL,
    "EntityType" character varying(100) NOT NULL,
    "EntityId" character varying(36) NOT NULL,
    "Before" text,
    "After" text,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO arlink28;

--
-- Data for Name: DestinationAttractions; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."DestinationAttractions" ("Id", "DestinationId", "Name", "Summary", "PhotoPath", "PhotoAlt", "PhotoCredit", "SortOrder", "CreatedAt", "UpdatedAt") FROM stdin;
\.


--
-- Data for Name: Destinations; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Destinations" ("Id", "Slug", "Name", "Country", "Kind", "Status", "ParentId", "Tagline", "Summary", "Description", "BestTimeToVisit", "HeroPath", "HeroAlt", "HeroCredit", "Latitude", "Longitude", "SortOrder", "PublishedAt", "CreatedAt", "UpdatedAt") FROM stdin;
eb2d59e3-ac54-4d93-b88c-3da09d04c9d2	kenya	Kenya	KE	Country	Draft	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
f1da7e79-5a02-49b0-902e-68145c23d5e3	nairobi	Nairobi	KE	Place	Published	eb2d59e3-ac54-4d93-b88c-3da09d04c9d2	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
\.


--
-- Data for Name: Enquiries; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Enquiries" ("Id", "Reference", "Type", "Status", "PackageId", "PackageTitle", "CheckIn", "Nights", "QuotedTotalMinor", "Currency", "Name", "Email", "Phone", "Subject", "Message", "ConsentAt", "SourceUrl", "HandledById", "CreatedAt", "UpdatedAt") FROM stdin;
42638c3b-72ce-49d8-934b-b5237a420af4	ENQ-2026-0001	General	New	\N	\N	\N	\N	\N	\N	Playwright test 23:23:46 (ignore)	developers@arlink28.com	+44 7000 000000	Mail test 23:23:46 - contact form	Automated test of the contact form email routing. Please ignore.	2026-10-15 23:23:47.775762+00	/contact	\N	2026-10-15 23:23:47.775762+00	2026-10-15 23:23:47.775762+00
84c66f82-a9de-44b3-b72b-b8a5949891eb	ENQ-2026-0002	Booking	New	\N	\N	\N	\N	\N	\N	Playwright test 23:23:46 (ignore)	developers@arlink28.com	+44 7000 000000	Flight quote: Mail test destination	Service: Flight\nDestination: Mail test destination\nTravellers: 1 person\n\nAutomated test of the quote email routing 23:23:46. Please ignore.	2026-10-15 23:23:57.506447+00	/quote	\N	2026-10-15 23:23:57.506447+00	2026-10-15 23:23:57.506447+00
664f8419-53ce-4f70-8ef4-94b4c00a34b8	ENQ-2026-0003	Booking	New	\N	\N	\N	\N	\N	\N	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	Hotel reservation quote: Cape Town	Service: Hotel reservation\nDestination: Cape Town\nTravellers: 1 person\n\ntesting ignore this	2026-10-15 23:27:48.92886+00	/quote	\N	2026-10-15 23:27:48.92886+00	2026-10-15 23:27:48.92886+00
dfa8b115-ea99-4bfe-b1db-cf397c311a66	ENQ-2026-0004	General	New	\N	\N	\N	\N	\N	\N	Playwright email test	developers@arlink28.com	\N	Email test 2026-10-16T01:04:08.205Z	Automated check that enquiry emails send from production. Safe to delete.	2026-10-16 01:04:13.259535+00	/contact	\N	2026-10-16 01:04:13.259535+00	2026-10-16 01:04:13.259535+00
3965844a-abd7-4635-b4a3-0909e29ff40f	ENQ-2026-0005	Booking	New	\N	\N	\N	\N	\N	\N	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	Flight quote: Cape Town	Service: Flight\nDestination: Cape Town\nTravellers: 1 person\n\ntesting	2026-10-16 01:18:10.009061+00	/quote	\N	2026-10-16 01:18:10.009061+00	2026-10-16 01:18:10.009061+00
098ba038-42e1-4ef6-9a97-3d200c911146	ENQ-2026-0006	Package	New	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Giraffe Manor Family Experience	2026-10-17	5	2657600	USD	Prosper Tinarwo	shifttechgs1@gmail.com	+27814303023	\N	testing ignore	2026-10-16 02:19:08.923976+00	/contact?package=Giraffe+Manor+Family+Experience&slug=giraffe-manor-family-experience&checkIn=2026-10-17&nights=5	\N	2026-10-16 02:19:08.923976+00	2026-10-16 02:19:08.923976+00
\.


--
-- Data for Name: Features; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Features" ("Id", "Slug", "Label", "Icon", "CreatedAt") FROM stdin;
06d26b77-6072-47c1-a8c9-7f41997e7e83	meet-and-greet	Meet & greet service from the airport to the destination	people-group	2026-10-16 02:13:59.79865+00
29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	vip-airport-to-resort	VIP transfer from airport to resort	plane	2026-10-16 02:13:59.79865+00
2ce2ac79-841c-465b-923f-5dc5106b44e3	tips	Tips	hand-holding-dollar	2026-10-16 02:13:59.79865+00
369530dd-dbcf-4fe7-a4e8-da09eb4206c7	vip-home-to-airport	VIP transfer from home to airport	car	2026-10-16 02:13:59.79865+00
44d688c1-caa2-4f41-87b6-14a95030bca0	vat	VAT	receipt	2026-10-16 02:13:59.79865+00
4578c46a-05f6-4efc-8689-23d57bf4ba05	boules-croquet	Boules & croquet	baseball-bat-ball	2026-10-16 02:13:59.79865+00
55a674d9-c7ff-438e-b14f-81c304b70f52	personal-effects	Personal effects	suitcase	2026-10-16 02:13:59.79865+00
5ed14816-6744-407b-b9c7-3e25dec318af	massage-treatments	Massage treatments	spa	2026-10-16 02:13:59.79865+00
861b903c-b7c1-4cb2-a8e4-b052dc780ec5	afew-giraffe-centre	AFEW Giraffe Centre entry	ticket	2026-10-16 02:13:59.79865+00
a55e53f2-a1e9-479a-a536-6780bf407a41	luxury-spirits	Luxury spirits	wine-bottle	2026-10-16 02:13:59.79865+00
a755ca68-16b1-496a-bcda-8b529a09b921	all-meals	All meals	utensils	2026-10-16 02:13:59.79865+00
ab597b1d-b14b-49e5-b735-42e59c1455bc	retreat-access	Access to The Retreat during check-in & check-out	spa	2026-10-16 02:13:59.79865+00
b17f4b12-ceda-4499-b696-b2a28116674e	orchid-house-dining	Orchid House dining	utensils	2026-10-16 02:13:59.79865+00
c0fc5481-9e17-48d5-8237-fb6a8dc39134	selected-wines	Selected wines	wine-glass-empty	2026-10-16 02:13:59.79865+00
c9d32790-1fd1-469e-8326-6a95ad6ef1cd	house-drinks	House wines, soft drinks, beers & spirits	wine-glass	2026-10-16 02:13:59.79865+00
cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	laundry	Laundry	shirt	2026-10-16 02:13:59.79865+00
dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	wifi	Wi-Fi	wifi	2026-10-16 02:13:59.79865+00
de9ac8e5-85f5-4c7c-8c54-b31d83f94636	champagne	Champagne	champagne-glasses	2026-10-16 02:13:59.79865+00
e6040660-0d06-4f1d-bf65-7d1d5c6db260	karen-langata-transfers	Arrival & departure transfers – Karen & Langata area	van-shuttle	2026-10-16 02:13:59.79865+00
eede9629-2716-46c7-9fcf-406c54cd6b3f	health-insurance	Health insurance	notes-medical	2026-10-16 02:13:59.79865+00
\.


--
-- Data for Name: PackageAddOns; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageAddOns" ("Id", "PackageId", "Name", "Description", "Unit", "Currency", "PriceMinor", "SortOrder") FROM stdin;
b328b9d0-6eea-437a-b899-8320a382f708	46a039e6-d50d-4f47-ac0e-30ab22d97535	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
9d2aa533-4b2b-42a9-a992-6cbe79f0f613	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
2de3349a-618f-470a-adca-5bcb218108b5	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
d8c807e3-8265-4ad0-b1f9-9cad6226e487	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
39d888ba-2ebb-4e49-9a41-3a6cb19800d9	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
9314d1eb-8ebf-4dff-9e82-cd64151ea653	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Private Nairobi National Park vehicle	Exclusive use of a vehicle for up to 6 guests, with the park entrance fees included. It cannot be combined with the arrival or departure transfer.	PerStay	USD	49000	0
\.


--
-- Data for Name: PackageFeatures; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageFeatures" ("Id", "PackageId", "Section", "FeatureId", "LabelOverride", "Footnote", "SortOrder") FROM stdin;
2a7c4547-886c-45a7-9840-dae896800eaa	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
474b0f4b-aadd-4c16-ab7a-cfcabafd9363	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
4c2b60a3-64df-42e4-85a5-c1b5378f5d4f	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
4d5b9da0-03f6-44c7-a984-6adf6afdcf00	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
540a8dd8-1098-4b92-bd8c-b39e6c0a7b46	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
580a0cf2-1a67-4c0c-a578-9af29a9e41fb	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
584bbba6-e664-4bd0-a282-bdd95187392b	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
69c9d125-6dcf-433f-b89b-07ed495fd9ac	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
7174fd39-0ad5-4acd-a2f2-61c8a29fdccd	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
75444626-b26f-4ddf-9f4b-49318be53f28	46a039e6-d50d-4f47-ac0e-30ab22d97535	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
84804a63-3515-440c-a3f8-23a0b378eb13	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
8de655a7-62b6-4620-8692-950ecfc2cc21	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
96046249-410a-4e89-ab45-4ea6f5914f59	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
99a7da01-d26a-4a4e-b08c-508e495bd98f	46a039e6-d50d-4f47-ac0e-30ab22d97535	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
b72eb6eb-b259-4ad6-88ac-54064334b661	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
b99395e3-83ab-4ee2-a24c-6c00cceef905	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
c2c91b6e-2688-44d2-becf-7faca4d41add	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
d956123c-7b5f-4e51-b54f-c9e2ba51872e	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
df780455-9244-4955-95af-ff440c93cbaa	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
e0dee776-3771-4898-bc54-dddb5dcc6edd	46a039e6-d50d-4f47-ac0e-30ab22d97535	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
e376d236-5830-4b79-a17a-27fe50a86944	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
eca0ace2-6dd4-4317-b48e-a2c6bac78d58	46a039e6-d50d-4f47-ac0e-30ab22d97535	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
ed891fa4-1ebd-456f-804c-258b3d64c9ed	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
f45091f9-178d-45b1-bd43-9e301c07a674	46a039e6-d50d-4f47-ac0e-30ab22d97535	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
faa9d172-264b-41be-b522-69f7a6e92b24	46a039e6-d50d-4f47-ac0e-30ab22d97535	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
1a4bcdb5-1f17-4f22-8e8c-b8968a34ce97	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
22f5b8c6-fc82-4501-baca-ff9d3ad373d2	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
29ae4270-bf24-4d00-88bc-bbcb52cf8de9	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
385731de-b87d-4672-b201-99526b559dfd	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
3bf268f1-a339-40b4-86f1-7d5652206991	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
426b30e3-3966-47f1-a387-6c70d901001c	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
5a9b213f-346a-4def-a61f-5dff02500f6a	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
67bf42d3-2d00-4103-9ce6-419898fafca6	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
76c4ad1d-8670-4c7c-ba7f-3abba7db0709	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
7ba8fc93-9244-4acb-bcc5-2a15240e9b98	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
816c0455-94b6-4acb-911f-43de942a6757	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
8dddc510-9c50-432f-be82-7ef6a94752d3	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
8fadab81-ecb6-45ed-992b-d618045609f6	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
901d8047-c85b-42ce-b6e5-cde371ab7b55	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
96d7b957-0869-4f6d-ad20-ef7be99ae492	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
9e4dc76f-0066-48c3-a0cd-1f213ebe2738	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
b3bea5c7-a826-4c40-aa36-cba5d37680ef	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
c227f708-6508-4ced-abb2-c4680b0a0d4e	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
c791cf6a-5746-4444-8b59-96498a6751aa	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
c9696787-db60-4942-abea-c74d446da61e	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
d4cc79a7-9bcf-491b-b151-b839b4664203	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
e245b1c9-16e2-49e6-b005-893dbf6a7e10	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
e99008b8-e8a9-4dc1-a798-c3c3a98e8122	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
f0519984-6ece-4a59-a8bf-fba5b62c0612	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
f1ea0923-95db-411f-b9b9-902c97f86228	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
00b251d8-d4b1-47f6-92ef-e059a20eb55c	5daabefd-e115-48ab-a84e-33e6eb68f7f9	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
00fc8a5c-9488-41ed-bc1f-2c1537610b1b	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
07b80368-b619-40c2-98b9-271f11b431f7	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
0864240e-25e2-418a-8fb0-924949eb2ece	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
0f6f726d-d134-4962-bac5-dff6169872df	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
187f65ca-3059-48bc-9984-c15cb6d19821	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
2396ba1d-cb9a-41d8-9e7c-f1f62f7c51c8	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
42a4dff6-10bd-46bb-900a-9d0301f3c8ed	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
4bd53161-aaa7-417a-9efa-06e4e0291f73	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
6cd596ec-cd29-4932-9598-a3945c40d11c	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
6f920658-b9b8-4f7b-9e83-dfdfc7401139	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
7aec5f44-f529-4423-9c3f-82848cb1b1c5	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
823a48e8-7386-4cda-a7c3-22270acc7f86	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
89498a28-3e26-49fd-a258-348f02ba4027	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
89e2333a-d159-4986-9bd8-f96b95ebe5ea	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
98dbd279-f1d0-4a80-acd3-c0c2508e8031	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
9e0b6948-ed80-4ef1-abbf-238c68d6cf5f	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
a768a071-f9c0-4bbf-bbd8-cf178053f6cd	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
acee3005-8a75-4f34-b4eb-35c668805c08	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
b68137a2-c398-4ec1-a2b1-d745f9561717	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
b7c5171b-61e4-4e51-9a7e-9220a0f693ce	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
b99f06f2-5226-4151-b24c-cf2c4b88c0ce	5daabefd-e115-48ab-a84e-33e6eb68f7f9	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
d044d522-f845-4b77-94d3-a48923f46044	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
ef668ed1-1fba-4793-92b2-704808c48f29	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
fb792ff6-e795-48b8-bd5d-48106cccbaa0	5daabefd-e115-48ab-a84e-33e6eb68f7f9	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
15ed12b2-8b72-40cb-ab17-8814b51f2197	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
1cc78af3-2446-499a-8b58-433dae329f94	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
1d146569-eccd-4654-b8c4-0948340ee8ce	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
1d2c4230-dfe0-4cbc-a42e-dc2f3b3149b9	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
308ac635-268d-47ff-aa0f-624015f78fbc	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
329a5b64-bac3-4842-9afd-1fcb7e179b80	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
39ab3000-8768-4bc7-a0ea-0763fbcfbcc7	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
448ef4b8-43e9-4814-a202-6ac2ddd8c530	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
4a6e380a-dd13-4ca0-bbcc-48bd78f852f5	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
5a4aa1c7-41ed-4332-bf04-d51fcefded05	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
5f9e3399-a522-4ea9-bee5-a0616da27385	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
66738c94-9815-4c59-9725-716084c04665	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	A third child is charged in addition to the suite minimum.	\N	5
73b173f0-91eb-49e4-883e-9cb7e928db75	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
8345bde3-63e0-4ac5-8217-808a25135394	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
a6d61e7c-9484-45e8-9e5d-8404e3a4c262	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
be0087b5-e4f3-4b96-8784-66bb303effbe	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
cb4d0782-c408-46ab-a65d-98f1a183bc9b	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
cb664dba-3bfa-42f6-9679-a4ea7268aa11	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
d4ee06e5-cc60-4cef-a8c3-467b7124263d	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
d74493a4-65e2-4ca0-8433-4f010bfd9f40	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
d9e43724-63ed-4f69-a08d-ff4396ca934c	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
e7fb124d-86b8-4337-b7d7-5f0f41461b6d	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
ed2d8883-c22c-4c74-8d25-e9bd2d68188d	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
f0f548d4-f7dd-41bb-9406-8699c4621854	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
f4f501c3-9bf9-4aa9-9b2b-f5c6de8dc531	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
ff47c48f-08f1-4ba8-9e7d-5b8d1736ee22	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
095ef301-d203-4283-913c-d15739ed4061	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
18b63d07-9bdb-4772-adc5-fd4c32c7bb3d	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
33b8ddd6-da8a-488a-a98c-a00f1b7844e7	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
3bbee5ab-5754-4c3b-89c0-728368b339a0	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
4932381f-069f-43c3-b69c-3ef27e97d582	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
58aa50b4-c2df-4371-9142-4b6523752826	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
5bd80e72-9b9a-4710-b884-0184beabfa36	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
62186d31-d761-4335-bd1f-efe8d8e1fa86	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
62524268-5408-4d41-a3ae-3f13fc1f4111	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
702a28d1-ef6e-45fc-bd9c-91ab02c7651f	d4d1b4e2-95d8-41fc-88a7-a25103292e81	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
840ab91a-529b-40f8-b4ab-81954813a7a4	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
8767f19e-e1c3-45f4-b536-b7bbe934f224	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
947a6e77-6cbf-4bdd-afe8-970cc303e543	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
994e17bb-8715-4b9d-a241-0761eea8830f	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
a208ebb4-98d5-450d-85d1-d19f1d3aa0e8	d4d1b4e2-95d8-41fc-88a7-a25103292e81	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
b3aaefd7-cbf5-41a5-b496-d5d9760238dc	d4d1b4e2-95d8-41fc-88a7-a25103292e81	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
b55546a7-b32d-4a77-bec1-5a51d2e99704	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
b79cfd22-fb48-4c32-a6e0-6ba78bea61a9	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
d2877636-793f-424f-9ff0-34bd5fe2cdcc	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
da7f712a-941e-4945-96ee-ac20a670d0e0	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
e653bb50-6a2f-414c-bc96-3efe562a36db	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
eaff234b-4384-4293-8e41-669fca3e44a8	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
ebc974ed-d12f-43b9-a622-65e262fe4f01	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
f1ce9754-f15f-4c72-a8b6-15576199a50b	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
f9887aa7-a6ef-41d0-8f9a-d9f03def96a3	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
0dc293d5-a24f-4b43-8d92-440897c04a21	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	de9ac8e5-85f5-4c7c-8c54-b31d83f94636	\N	\N	0
263f4634-c877-4bf8-b124-4e944ce9ab24	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	4578c46a-05f6-4efc-8689-23d57bf4ba05	\N	\N	7
32e93496-a2b5-4ec8-a8d5-35873cf97277	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	PremiumService	29bfc2fb-810d-4ea1-8bc4-bfdc8344aced	\N	\N	2
56d55fd7-c7b8-4430-a8db-667be7c937dc	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	An early arrival or a late departure may need Retreat access booked separately, subject to availability.	\N	1
60ba63d3-e12b-488b-867a-fdd005f1c9a2	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	PremiumService	06d26b77-6072-47c1-a8c9-7f41997e7e83	Meet & greet service at the airport	\N	1
67db48d1-54bf-48e8-b85b-46e8e53287aa	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Check-in is from 12 noon and check-out is by 10:00 a.m.	\N	0
69a2640b-8e33-42bd-9cb1-09cc47e3a296	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	55a674d9-c7ff-438e-b14f-81c304b70f52	\N	\N	6
750349fd-b653-406b-a4d0-0afe2cbcfde1	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	c9d32790-1fd1-469e-8326-6a95ad6ef1cd	\N	\N	1
768a1b43-30ed-4629-9af2-1e34224474a6	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	dcd88b59-3ba2-4abe-87dc-43cb2e46b5cc	\N	\N	3
778d9139-881d-4bf1-b59d-6ebfa17100a8	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	ab597b1d-b14b-49e5-b735-42e59c1455bc	\N	\N	6
7a3fdd17-49e1-42ce-a9b0-a6c213e527b6	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	5ed14816-6744-407b-b9c7-3e25dec318af	\N	\N	5
7a49f7f0-fbac-4bbd-9358-ed0d3c3f2c10	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	2ce2ac79-841c-465b-923f-5dc5106b44e3	\N	\N	3
8a92931c-3292-4e9f-8c02-aa59da92327d	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	b17f4b12-ceda-4499-b696-b2a28116674e	\N	\N	5
90de5f50-98c8-4c38-9703-b4914a03e86a	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Child sharing and extra bed arrangements are confirmed with the booking where they apply.	\N	4
9786fd89-5d04-4d80-a1ef-bc746bf178bf	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	eede9629-2716-46c7-9fcf-406c54cd6b3f	\N	\N	4
a9eb89bb-417f-42dd-886d-8cb3a46990ba	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Children aged 3 to 11 are classed as children, guests aged 12 and over as adults, and infants aged 0 to 2 stay free.	\N	3
b672c79a-de2b-4d8b-8659-8311f773628c	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Note	\N	Arrival and departure transfers are included when the arrival collection is after 11:30 a.m. and the departure transfer is before the 10:00 a.m. check-out.	\N	2
bf5fd171-3572-4901-9c6d-51860f97b088	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	44d688c1-caa2-4f41-87b6-14a95030bca0	\N	\N	8
bfc79dd7-c322-4521-a43f-a5e98b8ff5a3	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	PremiumService	369530dd-dbcf-4fe7-a4e8-da09eb4206c7	VIP transfer from home to airport	If required	0
d948e285-5c17-4c5c-a1c0-9c65983a4c7a	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	a55e53f2-a1e9-479a-a536-6780bf407a41	\N	\N	1
e85cc40f-c33f-4af2-b739-546894b61f1a	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	861b903c-b7c1-4cb2-a8e4-b052dc780ec5	\N	\N	4
eb275b78-4297-493e-a0a4-25b15e5023d0	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	cb59e7a9-b6d6-49c3-87d9-0b0ec113fef8	Laundry service	\N	2
ecefbdb1-dc13-4cee-98a7-b43380cbc4bb	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	a755ca68-16b1-496a-bcda-8b529a09b921	\N	\N	0
ee239781-3fcd-439d-955e-40f3ec3ae4d6	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Excluded	c0fc5481-9e17-48d5-8237-fb6a8dc39134	\N	\N	2
fcf83c4a-6646-410f-8ece-60f890b868d0	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Included	e6040660-0d06-4f1d-bf65-7d1d5c6db260	\N	Subject to applicable collection and departure times.	9
\.


--
-- Data for Name: PackageMedia; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageMedia" ("Id", "PackageId", "Role", "Path", "Alt", "Caption", "Width", "Height", "VideoProvider", "VideoId", "VariantsReady", "SortKey", "CreatedAt") FROM stdin;
28763826-099d-4f73-bc71-11a36c4ce90a	46a039e6-d50d-4f47-ac0e-30ab22d97535	Gallery	/images/packages/gm-savanna.jpg?for=giraffe-manor-solo-escape	An acacia tree at sunset on the savanna	\N	\N	\N	\N	\N	t	4	2026-10-16 02:33:07.577045+00
415e5392-e8d8-4ff0-8ad8-af83cf02b1cd	46a039e6-d50d-4f47-ac0e-30ab22d97535	Gallery	/images/packages/gm-dining.jpg?for=giraffe-manor-solo-escape	A lodge dining room with a timber ceiling	\N	\N	\N	\N	\N	t	2	2026-10-16 02:33:07.577045+00
5fbb4d51-6b70-4bf0-96d4-6eec84e3da7c	46a039e6-d50d-4f47-ac0e-30ab22d97535	Gallery	/images/packages/gm-lodge.jpg?for=giraffe-manor-solo-escape	The open-air lounge of a thatched lodge	\N	\N	\N	\N	\N	t	3	2026-10-16 02:33:07.577045+00
c5b507bb-ce4d-484e-8b2e-96c4ef5f66e6	46a039e6-d50d-4f47-ac0e-30ab22d97535	Gallery	/images/packages/gm-giraffe.jpg?for=giraffe-manor-solo-escape	A giraffe on the open plains	\N	\N	\N	\N	\N	t	1	2026-10-16 02:33:07.577045+00
d6e532ef-94c9-4b2a-a1e1-496e12489271	46a039e6-d50d-4f47-ac0e-30ab22d97535	Hero	/images/packages/gm-pool.jpg?for=giraffe-manor-solo-escape	A guest watching a giraffe from a lodge pool	\N	\N	\N	\N	\N	t	0	2026-10-16 02:33:07.577045+00
1944b021-b0a3-43af-9baa-a507c339fa60	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Gallery	/images/packages/gm-herd.jpg?for=giraffe-manor-signature-escape	Giraffes crossing dry grassland	\N	\N	\N	\N	\N	t	4	2026-10-16 02:33:07.577045+00
69b6aa03-1d97-4fd6-b119-50ec4bb19cde	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Gallery	/images/packages/gm-dining.jpg?for=giraffe-manor-signature-escape	A lodge dining room with a timber ceiling	\N	\N	\N	\N	\N	t	1	2026-10-16 02:33:07.577045+00
a4b48e1a-7eb6-4a46-84ac-936edf3665fa	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Hero	/images/packages/gm-giraffe.jpg?for=giraffe-manor-signature-escape	A giraffe on the open plains	\N	\N	\N	\N	\N	t	0	2026-10-16 02:33:07.577045+00
cbd8de93-46f0-4755-8620-b180f7cdf9a3	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Gallery	/images/packages/gm-lodge.jpg?for=giraffe-manor-signature-escape	The open-air lounge of a thatched lodge	\N	\N	\N	\N	\N	t	3	2026-10-16 02:33:07.577045+00
d38ac030-288c-4859-8d48-39c4870e3afb	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	Gallery	/images/packages/gm-pool.jpg?for=giraffe-manor-signature-escape	A guest watching a giraffe from a lodge pool	\N	\N	\N	\N	\N	t	2	2026-10-16 02:33:07.577045+00
7f9c7e08-2b08-438e-a9c9-0e1906621b92	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Gallery	/images/packages/gm-giraffe.jpg?for=giraffe-manor-family-experience	A giraffe on the open plains	\N	\N	\N	\N	\N	t	1	2026-10-16 02:33:07.577045+00
8bfb7459-3088-4f14-98db-70f2e0812a48	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Gallery	/images/packages/gm-dining.jpg?for=giraffe-manor-family-experience	A lodge dining room with a timber ceiling	\N	\N	\N	\N	\N	t	3	2026-10-16 02:33:07.577045+00
9fa94823-4f89-4529-9f15-9a885496b832	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Hero	/images/packages/gm-herd.jpg?for=giraffe-manor-family-experience	Giraffes crossing dry grassland	\N	\N	\N	\N	\N	t	0	2026-10-16 02:33:07.577045+00
be035262-da50-495f-846f-d05e45b7a4f0	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Gallery	/images/packages/gm-savanna.jpg?for=giraffe-manor-family-experience	An acacia tree at sunset on the savanna	\N	\N	\N	\N	\N	t	4	2026-10-16 02:33:07.577045+00
cfd10a05-122c-42b9-8401-7fa2f7e8c8dd	5daabefd-e115-48ab-a84e-33e6eb68f7f9	Gallery	/images/packages/gm-lodge.jpg?for=giraffe-manor-family-experience	The open-air lounge of a thatched lodge	\N	\N	\N	\N	\N	t	2	2026-10-16 02:33:07.577045+00
01711540-d850-4492-acf6-c7d2db4ae78f	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Hero	/images/packages/gm-lodge.jpg?for=giraffe-manor-extended-family-package	The open-air lounge of a thatched lodge	\N	\N	\N	\N	\N	t	0	2026-10-16 02:33:07.577045+00
3ab02725-ffd8-4b16-90f9-906a6db6fe8a	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Gallery	/images/packages/gm-pool.jpg?for=giraffe-manor-extended-family-package	A guest watching a giraffe from a lodge pool	\N	\N	\N	\N	\N	t	3	2026-10-16 02:33:07.577045+00
463e8142-3f86-4e37-9fd9-83df87bc76ac	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Gallery	/images/packages/gm-dining.jpg?for=giraffe-manor-extended-family-package	A lodge dining room with a timber ceiling	\N	\N	\N	\N	\N	t	4	2026-10-16 02:33:07.577045+00
e4e5f2fa-3581-46a1-aa6e-648069466f14	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Gallery	/images/packages/gm-herd.jpg?for=giraffe-manor-extended-family-package	Giraffes crossing dry grassland	\N	\N	\N	\N	\N	t	2	2026-10-16 02:33:07.577045+00
fcd3c9cb-f9f2-4673-98ce-0da84e187b67	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	Gallery	/images/packages/gm-giraffe.jpg?for=giraffe-manor-extended-family-package	A giraffe on the open plains	\N	\N	\N	\N	\N	t	1	2026-10-16 02:33:07.577045+00
326ef5d3-bd0a-4a99-b45d-2cf00bc03c2f	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Gallery	/images/packages/gm-herd.jpg?for=giraffe-manor-family-and-friends-retreat-3-adults	Giraffes crossing dry grassland	\N	\N	\N	\N	\N	t	4	2026-10-16 02:33:07.577045+00
595ffd85-c093-4b76-bcad-9c3902ec2d3b	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Gallery	/images/packages/gm-giraffe.jpg?for=giraffe-manor-family-and-friends-retreat-3-adults	A giraffe on the open plains	\N	\N	\N	\N	\N	t	2	2026-10-16 02:33:07.577045+00
5b756043-1062-4c97-aaa5-4166e579c2d7	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Hero	/images/packages/gm-dining.jpg?for=giraffe-manor-family-and-friends-retreat-3-adults	A lodge dining room with a timber ceiling	\N	\N	\N	\N	\N	t	0	2026-10-16 02:33:07.577045+00
a3e594da-b1f7-4f89-97d4-da596173dc3e	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Gallery	/images/packages/gm-lodge.jpg?for=giraffe-manor-family-and-friends-retreat-3-adults	The open-air lounge of a thatched lodge	\N	\N	\N	\N	\N	t	1	2026-10-16 02:33:07.577045+00
d49c0c0d-1b3d-4c89-b9cc-2f2630eadd74	d4d1b4e2-95d8-41fc-88a7-a25103292e81	Gallery	/images/packages/gm-savanna.jpg?for=giraffe-manor-family-and-friends-retreat-3-adults	An acacia tree at sunset on the savanna	\N	\N	\N	\N	\N	t	3	2026-10-16 02:33:07.577045+00
14bcdff4-a660-4341-a38e-186b07896364	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Gallery	/images/packages/gm-giraffe.jpg?for=giraffe-manor-family-and-friends-retreat-4-adults	A giraffe on the open plains	\N	\N	\N	\N	\N	t	2	2026-10-16 02:33:07.577045+00
1c76bd5e-61fd-426c-b015-1ba23f23d535	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Gallery	/images/packages/gm-herd.jpg?for=giraffe-manor-family-and-friends-retreat-4-adults	Giraffes crossing dry grassland	\N	\N	\N	\N	\N	t	1	2026-10-16 02:33:07.577045+00
45c750ca-e9d3-4999-a903-e9727f72ee8c	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Hero	/images/packages/gm-savanna.jpg?for=giraffe-manor-family-and-friends-retreat-4-adults	An acacia tree at sunset on the savanna	\N	\N	\N	\N	\N	t	0	2026-10-16 02:33:07.577045+00
b5640e78-d251-4245-86a9-ef0071e0cdb8	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Gallery	/images/packages/gm-pool.jpg?for=giraffe-manor-family-and-friends-retreat-4-adults	A guest watching a giraffe from a lodge pool	\N	\N	\N	\N	\N	t	4	2026-10-16 02:33:07.577045+00
c7ab6706-551f-4b77-aa28-fa63aa59ac97	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	Gallery	/images/packages/gm-lodge.jpg?for=giraffe-manor-family-and-friends-retreat-4-adults	The open-air lounge of a thatched lodge	\N	\N	\N	\N	\N	t	3	2026-10-16 02:33:07.577045+00
\.


--
-- Data for Name: PackageRates; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageRates" ("Id", "PackageId", "SeasonId", "Currency", "PriceMinor", "ExtraNightPriceMinor") FROM stdin;
98dbbf53-9ba1-4f61-808b-970d622dfd46	46a039e6-d50d-4f47-ac0e-30ab22d97535	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	698670	\N
c60d4fcb-bd50-4c7a-9274-c82e4bc6d76e	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	1413000	\N
74155d81-3fc3-46f8-bbe9-761be42649af	5daabefd-e115-48ab-a84e-33e6eb68f7f9	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	2657600	\N
d17368fc-747b-4f83-9b77-2731b7631f95	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	2863350	\N
7c5a6ddb-9d7d-4d9d-bafc-b0c01b6c7ae6	d4d1b4e2-95d8-41fc-88a7-a25103292e81	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	3720640	\N
2de7d819-e878-4abb-b9be-a9da3aa92f85	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	USD	4154220	\N
\.


--
-- Data for Name: PackageStays; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PackageStays" ("Id", "PackageId", "PropertyId", "Nights", "RoomType", "SortOrder") FROM stdin;
6c86185f-54a9-463c-a5d6-2e8116d66452	46a039e6-d50d-4f47-ac0e-30ab22d97535	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	3	Superior Single Room	0
9a49d9d5-1b2d-4297-8634-b8248b10a826	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	5	Superior Room	0
da1791bd-b5e2-4d22-bed1-42b9ddf8cdb2	5daabefd-e115-48ab-a84e-33e6eb68f7f9	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	5	Karen Blixen / Finch Hatton Suite	0
bcd02068-d452-4473-844f-f99793828465	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	5	Karen Blixen / Finch Hatton Suites	0
2d8225f7-0e87-4828-8e64-d4be3b0c5f24	d4d1b4e2-95d8-41fc-88a7-a25103292e81	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	7	Karen Blixen / Finch Hatton Suites	0
4eec5f08-86fa-45b2-9c69-8474320f75da	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	7	Karen Blixen / Finch Hatton Suite	0
\.


--
-- Data for Name: Packages; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Packages" ("Id", "Slug", "ProductType", "Details", "Status", "Title", "Subtitle", "Summary", "Description", "Category", "DestinationId", "Nights", "MinNights", "Adults", "Children", "PricingBasis", "BaseCurrency", "FromPriceMinor", "Featured", "SortOrder", "SeoTitle", "SeoDescription", "Version", "PublishedAt", "CreatedAt", "UpdatedAt") FROM stdin;
46a039e6-d50d-4f47-ac0e-30ab22d97535	giraffe-manor-solo-escape	HolidayPackage	\N	Published	Giraffe Manor Solo Escape	3 Nights / 4 Days for One Adult	An intimate, fully inclusive Giraffe Manor stay with meals, selected house drinks, Giraffe Centre access and qualifying transfers.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	3	3	1	0	PerParty	USD	698670	t	100	\N	\N	1	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	giraffe-manor-signature-escape	HolidayPackage	\N	Published	Giraffe Manor Signature Escape	5 Nights / 6 Days for Two Adults	A fully inclusive stay for two with meals, selected house drinks, Giraffe Centre access and qualifying transfers.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	5	5	2	0	PerParty	USD	1413000	t	110	\N	\N	1	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
5daabefd-e115-48ab-a84e-33e6eb68f7f9	giraffe-manor-family-experience	HolidayPackage	\N	Published	Giraffe Manor Family Experience	5 Nights / 6 Days for Two Adults + Up to Two Children	A family stay in a two-bedroom suite with the Giraffe Manor fully inclusive experience.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	5	5	2	2	PerParty	USD	2657600	t	120	\N	\N	1	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	giraffe-manor-extended-family-package	HolidayPackage	\N	Published	Giraffe Manor Extended Family Package	5 Nights / 6 Days for Two Adults + Three Children	A family suite experience for a larger family, with a third child charged in addition to the suite minimum.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	5	5	2	3	PerParty	USD	2863350	t	130	\N	\N	1	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
d4d1b4e2-95d8-41fc-88a7-a25103292e81	giraffe-manor-family-and-friends-retreat-3-adults	HolidayPackage	\N	Published	Giraffe Manor Family and Friends Retreat (3 Adults)	7 Nights / 8 Days for Three Adults	A shared two-bedroom suite stay for three adults with the Giraffe Manor fully inclusive experience.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	7	7	3	0	PerParty	USD	3720640	t	140	\N	\N	1	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
cbcb141f-458b-45b5-8d16-d1d4a883bbb8	giraffe-manor-family-and-friends-retreat-4-adults	HolidayPackage	\N	Published	Giraffe Manor Family and Friends Retreat (4 Adults)	7 Nights / 8 Days for Four Adults	A shared two-bedroom suite stay for four adults with the Giraffe Manor fully inclusive experience.	\N	LODGE	f1da7e79-5a02-49b0-902e-68145c23d5e3	7	7	4	0	PerParty	USD	4154220	t	150	\N	\N	1	2026-10-16 02:13:59.79865+00	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
\.


--
-- Data for Name: Partners; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Partners" ("Id", "Slug", "Name", "Tagline", "LogoPath", "CreatedAt", "UpdatedAt") FROM stdin;
544979d3-cbf6-4ed4-95cf-c8138a167259	giraffe-manor	Giraffe Manor	An exclusive partnership. Extraordinary experiences.	\N	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
\.


--
-- Data for Name: Properties; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Properties" ("Id", "Slug", "Name", "PartnerId", "DestinationId", "CreatedAt", "UpdatedAt") FROM stdin;
df9c91e4-8a9c-4e0e-835b-a0d421fbe0a3	giraffe-manor	Giraffe Manor	544979d3-cbf6-4ed4-95cf-c8138a167259	f1da7e79-5a02-49b0-902e-68145c23d5e3	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
\.


--
-- Data for Name: PropertyMedia; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."PropertyMedia" ("Id", "PropertyId", "Path", "Alt", "Caption", "Width", "Height", "VideoProvider", "VideoId", "VariantsReady", "SortKey", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: SeasonRanges; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."SeasonRanges" ("Id", "SeasonId", "StartDate", "EndDate") FROM stdin;
76e36f18-c706-405e-a208-7d438ef51b65	2fab7c39-088e-4a6e-b2f2-f3c341b91e18	2026-01-01	2026-12-31
\.


--
-- Data for Name: Seasons; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Seasons" ("Id", "Slug", "Name", "PartnerId", "CreatedAt", "UpdatedAt") FROM stdin;
2fab7c39-088e-4a6e-b2f2-f3c341b91e18	giraffe-manor-2026	2026	544979d3-cbf6-4ed4-95cf-c8138a167259	2026-10-16 02:13:59.79865+00	2026-10-16 02:33:07.577045+00
\.


--
-- Data for Name: Staff; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."Staff" ("Id", "Username", "Email", "PasswordHash", "Role", "IsActive", "FailedLoginAttempts", "LockedUntil", "LastLoginAt", "InvitedById", "CreatedAt", "UpdatedAt") FROM stdin;
e9705320-15ae-4dc4-acca-7a9e0872bd64	developers	developers@arlink28.com	AQAAAAIAAYagAAAAEN28Y1oOQVyd7LEyTVKvOPOaGIeNuH9VydTnOulydLx2FviEWzr4YAMu3gZDOkxlow==	SuperAdmin	t	0	\N	2026-10-16 02:31:46.509047+00	\N	2026-10-14 22:50:48.990239+00	2026-10-16 02:31:46.509066+00
\.


--
-- Data for Name: StaffTokens; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."StaffTokens" ("Id", "Type", "TokenHash", "Email", "RoleToAssign", "StaffId", "ExpiresAt", "UsedAt", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20261014210441_InitialCreate	10.0.0
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: arlink28
--

COPY public.audit_logs ("Id", "ActorId", "Action", "EntityType", "EntityId", "Before", "After", "CreatedAt") FROM stdin;
9bb50cd7-bdf4-4250-b51c-3a699d5153a2	\N	Enquiry.Created	Enquiry	42638c3b-72ce-49d8-934b-b5237a420af4	\N	\N	2026-10-15 23:23:47.775762+00
2d3537d1-5efa-47fe-a83a-d4121d9f49bc	\N	Enquiry.Created	Enquiry	84c66f82-a9de-44b3-b72b-b8a5949891eb	\N	\N	2026-10-15 23:23:57.506447+00
2871d057-692e-4bf2-b21b-de97468f61c9	\N	Enquiry.Created	Enquiry	664f8419-53ce-4f70-8ef4-94b4c00a34b8	\N	\N	2026-10-15 23:27:48.92886+00
1c968bd3-6662-4c08-9970-d14e77d39d05	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:32:18.822304+00
db8a8988-8b4e-4bc6-9d6d-db91e78dc172	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:33:36.314447+00
2867a8a0-e03f-4ed1-84ec-4900b45e34f6	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:43:41.994324+00
b3b9f430-1b3a-430b-a00c-bb96cbddf48e	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 00:44:19.36717+00
acd034b8-1fad-4b97-bf51-104cf1e2ac91	\N	Enquiry.Created	Enquiry	dfa8b115-ea99-4bfe-b1db-cf397c311a66	\N	\N	2026-10-16 01:04:13.259535+00
c8e06ed8-94af-43fc-8625-f5f7ba42f6b8	\N	Enquiry.Created	Enquiry	3965844a-abd7-4635-b4a3-0909e29ff40f	\N	\N	2026-10-16 01:18:10.009061+00
a0ad905d-bb27-4046-9b6f-dd2e9f58d0f5	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:01:07.415804+00
0ee73261-a226-42e5-9403-8062e73dcf64	\N	seed.package.create	package	5daabefd-e115-48ab-a84e-33e6eb68f7f9	\N	{"Slug":"giraffe-manor-family-experience","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":2657600}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (2).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
1b9bdbea-569d-482b-a051-c5a47817ff2f	\N	seed.package.create	package	d4d1b4e2-95d8-41fc-88a7-a25103292e81	\N	{"Slug":"giraffe-manor-family-and-friends-retreat-3-adults","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":3720640}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (4).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
1d707fb6-2b77-4878-b495-cbcda3730307	\N	seed.package.create	package	46a039e6-d50d-4f47-ac0e-30ab22d97535	\N	{"Slug":"giraffe-manor-solo-escape","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":698670}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45.jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
c451fec6-365f-44e7-a4f9-95ac883935dc	\N	seed.package.create	package	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	\N	{"Slug":"giraffe-manor-signature-escape","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":1413000}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (1).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
d785f746-f30f-4f27-ab80-5aa9b25d1b67	\N	seed.package.create	package	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	\N	{"Slug":"giraffe-manor-family-and-friends-retreat-4-adults","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":4154220}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.46.jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
e66b5211-87c4-44e4-a107-4dd818b2c67b	\N	seed.package.create	package	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	\N	{"Slug":"giraffe-manor-extended-family-package","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":2863350}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (3).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:13:59.79865+00
d71cf39a-6d76-490d-850e-f7318fdf1eb6	\N	Enquiry.Created	Enquiry	098ba038-42e1-4ef6-9a97-3d200c911146	\N	\N	2026-10-16 02:19:08.923976+00
587d659b-e88c-48da-b98d-996fb703e2eb	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:24:16.271649+00
14c58c9f-7652-4d2e-bc25-f5608cfbae71	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:29:12.121145+00
1ca58955-0f6d-4b2f-b140-ceb00b557703	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogin	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:31:46.509528+00
777abeaa-cd34-489a-8ed7-2eb2a340aaa8	e9705320-15ae-4dc4-acca-7a9e0872bd64	StaffLogout	Staff	e9705320-15ae-4dc4-acca-7a9e0872bd64	\N	\N	2026-10-16 02:31:52.471984+00
d8cfb16c-e391-4f9d-9404-a26e5992096d	\N	seed.package.update	package	46a039e6-d50d-4f47-ac0e-30ab22d97535	\N	{"Slug":"giraffe-manor-solo-escape","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":698670}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45.jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:33:07.577045+00
cdab79e1-fcd6-4510-a69f-791b55a97d43	\N	seed.package.update	package	b0373e99-b0cb-4a15-bfb9-82f8ef6e75a6	\N	{"Slug":"giraffe-manor-signature-escape","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":1413000}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (1).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:33:07.577045+00
ddb10f1d-bde6-4f41-af28-38d476b257b0	\N	seed.package.update	package	5daabefd-e115-48ab-a84e-33e6eb68f7f9	\N	{"Slug":"giraffe-manor-family-experience","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":2657600}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (2).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:33:07.577045+00
18f0f208-c051-4932-8e9b-e8ff9402ec67	\N	seed.package.update	package	a324c89d-1ba6-46e2-89dd-4cdf0d314a0e	\N	{"Slug":"giraffe-manor-extended-family-package","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":2863350}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (3).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:33:07.577045+00
0fba4c16-fb17-497f-a004-ea1ed3c2cccb	\N	seed.package.update	package	d4d1b4e2-95d8-41fc-88a7-a25103292e81	\N	{"Slug":"giraffe-manor-family-and-friends-retreat-3-adults","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":3720640}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.45 (4).jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:33:07.577045+00
c24930a9-6b8d-491b-9a76-ade49a7b7bd6	\N	seed.package.update	package	cbcb141f-458b-45b5-8d16-d1d4a883bbb8	\N	{"Slug":"giraffe-manor-family-and-friends-retreat-4-adults","Status":"Published","Rates":[{"Season":"giraffe-manor-2026","PriceMinor":4154220}],"Sources":["WhatsApp Image 2026-10-08 at 15.36.46.jpeg","WhatsApp Image 2026-10-08 at 15.36.46 (1).jpeg"]}	2026-10-16 02:33:07.577045+00
\.


--
-- Name: DestinationAttractions PK_DestinationAttractions; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."DestinationAttractions"
    ADD CONSTRAINT "PK_DestinationAttractions" PRIMARY KEY ("Id");


--
-- Name: Destinations PK_Destinations; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Destinations"
    ADD CONSTRAINT "PK_Destinations" PRIMARY KEY ("Id");


--
-- Name: Enquiries PK_Enquiries; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "PK_Enquiries" PRIMARY KEY ("Id");


--
-- Name: Features PK_Features; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Features"
    ADD CONSTRAINT "PK_Features" PRIMARY KEY ("Id");


--
-- Name: PackageAddOns PK_PackageAddOns; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageAddOns"
    ADD CONSTRAINT "PK_PackageAddOns" PRIMARY KEY ("Id");


--
-- Name: PackageFeatures PK_PackageFeatures; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "PK_PackageFeatures" PRIMARY KEY ("Id");


--
-- Name: PackageMedia PK_PackageMedia; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageMedia"
    ADD CONSTRAINT "PK_PackageMedia" PRIMARY KEY ("Id");


--
-- Name: PackageRates PK_PackageRates; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "PK_PackageRates" PRIMARY KEY ("Id");


--
-- Name: PackageStays PK_PackageStays; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "PK_PackageStays" PRIMARY KEY ("Id");


--
-- Name: Packages PK_Packages; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Packages"
    ADD CONSTRAINT "PK_Packages" PRIMARY KEY ("Id");


--
-- Name: Partners PK_Partners; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Partners"
    ADD CONSTRAINT "PK_Partners" PRIMARY KEY ("Id");


--
-- Name: Properties PK_Properties; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "PK_Properties" PRIMARY KEY ("Id");


--
-- Name: PropertyMedia PK_PropertyMedia; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PropertyMedia"
    ADD CONSTRAINT "PK_PropertyMedia" PRIMARY KEY ("Id");


--
-- Name: SeasonRanges PK_SeasonRanges; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."SeasonRanges"
    ADD CONSTRAINT "PK_SeasonRanges" PRIMARY KEY ("Id");


--
-- Name: Seasons PK_Seasons; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Seasons"
    ADD CONSTRAINT "PK_Seasons" PRIMARY KEY ("Id");


--
-- Name: Staff PK_Staff; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "PK_Staff" PRIMARY KEY ("Id");


--
-- Name: StaffTokens PK_StaffTokens; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."StaffTokens"
    ADD CONSTRAINT "PK_StaffTokens" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: audit_logs PK_audit_logs; Type: CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "PK_audit_logs" PRIMARY KEY ("Id");


--
-- Name: IX_DestinationAttractions_DestinationId_SortOrder; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_DestinationAttractions_DestinationId_SortOrder" ON public."DestinationAttractions" USING btree ("DestinationId", "SortOrder");


--
-- Name: IX_Destinations_ParentId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Destinations_ParentId" ON public."Destinations" USING btree ("ParentId");


--
-- Name: IX_Destinations_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Destinations_Slug" ON public."Destinations" USING btree ("Slug");


--
-- Name: IX_Destinations_Status_Country_SortOrder; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Destinations_Status_Country_SortOrder" ON public."Destinations" USING btree ("Status", "Country", "SortOrder");


--
-- Name: IX_Enquiries_HandledById; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_HandledById" ON public."Enquiries" USING btree ("HandledById");


--
-- Name: IX_Enquiries_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_PackageId" ON public."Enquiries" USING btree ("PackageId");


--
-- Name: IX_Enquiries_Reference; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Enquiries_Reference" ON public."Enquiries" USING btree ("Reference");


--
-- Name: IX_Enquiries_Status_CreatedAt; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Enquiries_Status_CreatedAt" ON public."Enquiries" USING btree ("Status", "CreatedAt");


--
-- Name: IX_Features_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Features_Slug" ON public."Features" USING btree ("Slug");


--
-- Name: IX_PackageAddOns_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageAddOns_PackageId" ON public."PackageAddOns" USING btree ("PackageId");


--
-- Name: IX_PackageFeatures_FeatureId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageFeatures_FeatureId" ON public."PackageFeatures" USING btree ("FeatureId");


--
-- Name: IX_PackageFeatures_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageFeatures_PackageId" ON public."PackageFeatures" USING btree ("PackageId");


--
-- Name: IX_PackageMedia_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageMedia_PackageId" ON public."PackageMedia" USING btree ("PackageId");


--
-- Name: IX_PackageMedia_Path; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PackageMedia_Path" ON public."PackageMedia" USING btree ("Path");


--
-- Name: IX_PackageRates_PackageId_SeasonId_Currency; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PackageRates_PackageId_SeasonId_Currency" ON public."PackageRates" USING btree ("PackageId", "SeasonId", "Currency");


--
-- Name: IX_PackageRates_SeasonId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageRates_SeasonId" ON public."PackageRates" USING btree ("SeasonId");


--
-- Name: IX_PackageStays_PackageId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageStays_PackageId" ON public."PackageStays" USING btree ("PackageId");


--
-- Name: IX_PackageStays_PropertyId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PackageStays_PropertyId" ON public."PackageStays" USING btree ("PropertyId");


--
-- Name: IX_Packages_DestinationId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_DestinationId" ON public."Packages" USING btree ("DestinationId");


--
-- Name: IX_Packages_Featured_SortOrder_Id; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_Featured_SortOrder_Id" ON public."Packages" USING btree ("Featured", "SortOrder", "Id");


--
-- Name: IX_Packages_ProductType_Status; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Packages_ProductType_Status" ON public."Packages" USING btree ("ProductType", "Status");


--
-- Name: IX_Packages_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Packages_Slug" ON public."Packages" USING btree ("Slug");


--
-- Name: IX_Partners_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Partners_Slug" ON public."Partners" USING btree ("Slug");


--
-- Name: IX_Properties_DestinationId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Properties_DestinationId" ON public."Properties" USING btree ("DestinationId");


--
-- Name: IX_Properties_PartnerId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Properties_PartnerId" ON public."Properties" USING btree ("PartnerId");


--
-- Name: IX_Properties_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Properties_Slug" ON public."Properties" USING btree ("Slug");


--
-- Name: IX_PropertyMedia_Path; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_PropertyMedia_Path" ON public."PropertyMedia" USING btree ("Path");


--
-- Name: IX_PropertyMedia_PropertyId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_PropertyMedia_PropertyId" ON public."PropertyMedia" USING btree ("PropertyId");


--
-- Name: IX_SeasonRanges_SeasonId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_SeasonRanges_SeasonId" ON public."SeasonRanges" USING btree ("SeasonId");


--
-- Name: IX_Seasons_PartnerId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Seasons_PartnerId" ON public."Seasons" USING btree ("PartnerId");


--
-- Name: IX_Seasons_Slug; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Seasons_Slug" ON public."Seasons" USING btree ("Slug");


--
-- Name: IX_StaffTokens_Email_Type; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_StaffTokens_Email_Type" ON public."StaffTokens" USING btree ("Email", "Type");


--
-- Name: IX_StaffTokens_StaffId; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_StaffTokens_StaffId" ON public."StaffTokens" USING btree ("StaffId");


--
-- Name: IX_StaffTokens_TokenHash; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_StaffTokens_TokenHash" ON public."StaffTokens" USING btree ("TokenHash");


--
-- Name: IX_Staff_Email; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Staff_Email" ON public."Staff" USING btree ("Email");


--
-- Name: IX_Staff_InvitedById; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE INDEX "IX_Staff_InvitedById" ON public."Staff" USING btree ("InvitedById");


--
-- Name: IX_Staff_Username; Type: INDEX; Schema: public; Owner: arlink28
--

CREATE UNIQUE INDEX "IX_Staff_Username" ON public."Staff" USING btree ("Username");


--
-- Name: DestinationAttractions FK_DestinationAttractions_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."DestinationAttractions"
    ADD CONSTRAINT "FK_DestinationAttractions_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE CASCADE;


--
-- Name: Destinations FK_Destinations_Destinations_ParentId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Destinations"
    ADD CONSTRAINT "FK_Destinations_Destinations_ParentId" FOREIGN KEY ("ParentId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Enquiries FK_Enquiries_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "FK_Enquiries_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE SET NULL;


--
-- Name: Enquiries FK_Enquiries_Staff_HandledById; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Enquiries"
    ADD CONSTRAINT "FK_Enquiries_Staff_HandledById" FOREIGN KEY ("HandledById") REFERENCES public."Staff"("Id") ON DELETE SET NULL;


--
-- Name: PackageAddOns FK_PackageAddOns_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageAddOns"
    ADD CONSTRAINT "FK_PackageAddOns_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageFeatures FK_PackageFeatures_Features_FeatureId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "FK_PackageFeatures_Features_FeatureId" FOREIGN KEY ("FeatureId") REFERENCES public."Features"("Id") ON DELETE SET NULL;


--
-- Name: PackageFeatures FK_PackageFeatures_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageFeatures"
    ADD CONSTRAINT "FK_PackageFeatures_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageMedia FK_PackageMedia_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageMedia"
    ADD CONSTRAINT "FK_PackageMedia_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageRates FK_PackageRates_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "FK_PackageRates_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageRates FK_PackageRates_Seasons_SeasonId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageRates"
    ADD CONSTRAINT "FK_PackageRates_Seasons_SeasonId" FOREIGN KEY ("SeasonId") REFERENCES public."Seasons"("Id") ON DELETE RESTRICT;


--
-- Name: PackageStays FK_PackageStays_Packages_PackageId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "FK_PackageStays_Packages_PackageId" FOREIGN KEY ("PackageId") REFERENCES public."Packages"("Id") ON DELETE CASCADE;


--
-- Name: PackageStays FK_PackageStays_Properties_PropertyId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PackageStays"
    ADD CONSTRAINT "FK_PackageStays_Properties_PropertyId" FOREIGN KEY ("PropertyId") REFERENCES public."Properties"("Id") ON DELETE RESTRICT;


--
-- Name: Packages FK_Packages_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Packages"
    ADD CONSTRAINT "FK_Packages_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Properties FK_Properties_Destinations_DestinationId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "FK_Properties_Destinations_DestinationId" FOREIGN KEY ("DestinationId") REFERENCES public."Destinations"("Id") ON DELETE RESTRICT;


--
-- Name: Properties FK_Properties_Partners_PartnerId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "FK_Properties_Partners_PartnerId" FOREIGN KEY ("PartnerId") REFERENCES public."Partners"("Id") ON DELETE SET NULL;


--
-- Name: PropertyMedia FK_PropertyMedia_Properties_PropertyId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."PropertyMedia"
    ADD CONSTRAINT "FK_PropertyMedia_Properties_PropertyId" FOREIGN KEY ("PropertyId") REFERENCES public."Properties"("Id") ON DELETE CASCADE;


--
-- Name: SeasonRanges FK_SeasonRanges_Seasons_SeasonId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."SeasonRanges"
    ADD CONSTRAINT "FK_SeasonRanges_Seasons_SeasonId" FOREIGN KEY ("SeasonId") REFERENCES public."Seasons"("Id") ON DELETE CASCADE;


--
-- Name: Seasons FK_Seasons_Partners_PartnerId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Seasons"
    ADD CONSTRAINT "FK_Seasons_Partners_PartnerId" FOREIGN KEY ("PartnerId") REFERENCES public."Partners"("Id") ON DELETE SET NULL;


--
-- Name: StaffTokens FK_StaffTokens_Staff_StaffId; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."StaffTokens"
    ADD CONSTRAINT "FK_StaffTokens_Staff_StaffId" FOREIGN KEY ("StaffId") REFERENCES public."Staff"("Id") ON DELETE CASCADE;


--
-- Name: Staff FK_Staff_Staff_InvitedById; Type: FK CONSTRAINT; Schema: public; Owner: arlink28
--

ALTER TABLE ONLY public."Staff"
    ADD CONSTRAINT "FK_Staff_Staff_InvitedById" FOREIGN KEY ("InvitedById") REFERENCES public."Staff"("Id") ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict JeJ6T8eaUsECBztrsNBhFifYsYPiawFbXrQJxBjGaeyHIYMRmTmc8vhPCW0VCbQ

